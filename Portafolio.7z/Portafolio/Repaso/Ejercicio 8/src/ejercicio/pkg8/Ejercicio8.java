/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg8;

import java.util.Scanner;

/**
 *
 * @author Laboratorio
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       char caracter;
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese un caracter");
        caracter = sc.next().charAt(0);
        int num =(int)caracter;
        System.out.println(num);
    }
    
}
