/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg9;

import java.util.Scanner;




/**
 *
 * @author Laboratorio
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final double IVA=0.21;
        double precio;
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el precio del producto");
        precio = sc.nextDouble();
        System.out.println("El precio final es de " +(precio+(precio*IVA)));
        
        
    }

   
    
}
