/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg16;

import java.util.Scanner;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio16 {

    /**
     * 
     * @param args
     */
        public static void main(String[] args) {
        // TODO code application logic her
        Scanner sc = new Scanner(System.in);
        int intentos =3;
        while (intentos >0) {
            System.out.println("Ingrese la contraseña,Tiene "+intentos+" intentos");
            String cont = sc.nextLine();
            if (cont.equals("eithan")) {
                System.out.println("En hora buena");
                intentos = 0;
            } else {
                intentos = intentos - 1;
            }

        }
    }

}
