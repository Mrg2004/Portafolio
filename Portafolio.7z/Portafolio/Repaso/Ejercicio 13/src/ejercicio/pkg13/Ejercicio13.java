/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg13;

import java.util.Scanner;

/**
 *
 * @author Laboratorio
 */
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        System.out.println("Ingrese el numero de ventas");
        int ventas =sc.nextInt();
        int acuVentas=0;
        for (int i=1;i<=ventas;i++){
            System.out.println("Ingrese las ventas");
            int  toVentas =sc.nextInt();
            acuVentas = acuVentas+toVentas;
            
        }
        System.out.println("El total de ventas es de " +acuVentas);
    }
    
}
