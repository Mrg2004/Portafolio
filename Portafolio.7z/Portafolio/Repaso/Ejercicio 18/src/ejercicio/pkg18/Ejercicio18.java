/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg18;

import java.util.Scanner;
import java.math.*;
import java.util.Random;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int num1,num2;
        System.out.println("Ingrese el numero en que desea que inicie");
        num1 =sc.nextInt();
        System.out.println("Ingrese el numero en que desea que finalice");
        num2 = sc.nextInt();
        Random aleatorio = new Random ();
        for (int i=0;i<=10;i++){
            int num = aleatorio.nextInt()*num1 + num2;
        }
       
    }
    
}
