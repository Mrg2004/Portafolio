/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg15;

import java.util.Scanner;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int num;
        do {
            System.out.println("Ingrese un numero");
            num = sc.nextInt();
            if (num > 0) {
                System.out.println("El numero es mayor a cero " + num);
            } else if (num == 0) {
                System.out.println("El numero es igual a cero " + num);
            }
        } while (num < 0);
    }

}
