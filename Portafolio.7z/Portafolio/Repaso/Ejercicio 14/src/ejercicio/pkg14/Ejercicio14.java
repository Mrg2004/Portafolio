/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg14;

import java.util.Scanner;
import java.math.*;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        double numa, numb, numc, X1, X2;
        double discriminante;
        double op;
        System.out.println("Ingrese el numero a");
        numa = sc.nextInt();
        System.out.println("Ingrese el numero b");
        numb = sc.nextInt();
        System.out.println("Ingrese el numero c");
        numc = sc.nextInt();
        discriminante = ((numb * numb) - (4 * (numa * numc)));
        System.out.println("Discriminate " +discriminante);
        if (discriminante < 0) {
            System.out.println("La ecuacacion tiene solo una raiz");
            X1 = ((-numb) / (2 * numa));
            System.out.println("La solacion es X1=X2: " + X1);
        }
        if (discriminante > 0) {
            System.out.println("La ecuacuion tiene dos raices");
            X1 = ((-numb)+Math.sqrt(discriminante))/(2*numa);
            X2 = ((-numb)-Math.sqrt(discriminante))/(2*numa);
            System.out.println("La solucion de X1 = " + X1 + " La solucion de X2 = " + X2);

        }
    }

}
