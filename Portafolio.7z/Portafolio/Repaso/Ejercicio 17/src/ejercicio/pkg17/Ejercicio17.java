/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg17;

import java.util.Scanner;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese un dia de la semana");
        String dia = sc.nextLine();
        switch (dia){
            case "lunes":
                System.out.println("Dia Laboral");
                break;
        case "martes":
                System.out.println("Dia Laboral");
                break;
        case "miercoles":
                System.out.println("Dia Laboral");
                break;
        case "jueves":
                System.out.println("Dia Laboral");
                break;
        case "viernes":
                System.out.println("Dia Laboral");
                break;
        case "sabado":
                System.out.println("No es un dia laboral");
                break;
        case "domingo":
                System.out.println("No es un dia laboral");
                break;
        default:
            System.out.println("Dia de la semana invalido");
            break;
        
        }
        
    }
    
}
