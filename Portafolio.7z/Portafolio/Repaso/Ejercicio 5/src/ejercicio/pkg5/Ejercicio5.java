/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.Scanner;
import java.math.*;

/**
 *
 * @author Laboratorio
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        double radio;
        System.out.println("Ingrese el radio del circulo");
        radio = sc.nextDouble();
        System.out.println("El area es " +(Math.PI * Math.pow(radio, 2)));
        
        
    }
    
}
