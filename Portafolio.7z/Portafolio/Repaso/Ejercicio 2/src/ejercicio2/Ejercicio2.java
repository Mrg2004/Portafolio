/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * @author Laboratorio
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic 
        int num1 = 20, num2 = 20, numMayor;
        if (num1 > num2) {
            numMayor = num1;
            System.out.println("El numero mayor es " + numMayor);
        } else if (num1 == num2) {
            System.out.println("Los numeros son iguales");
        } else {
            numMayor = num2;
            System.out.println("El numero mayor es " + num2);
        }

        
    }
    
}
