/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

/**
 *
 * @author Laboratorio
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1 = 40;
        int num2 = 10;
        int suma, resta, division, multiplicacion, mod;
        suma = num1 + num2;
        System.out.println("El resultado de suma es " + suma);
        resta = num1 - num2;
        System.out.println("El resultado de resta es " + resta);
        division = num1 / num2;
        System.out.println("El resultado de division es " + division);
        multiplicacion = num1 * num2;
        System.out.println("El resultado de multiplicacion es " + multiplicacion);
        mod = num1 % num2;
        System.out.println("El resultado del modulo es " + mod);
      
    }
    
}
