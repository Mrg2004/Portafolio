package Interfaz;

import Clases.Pedido;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Clases.Producto;
import Clases.Cliente;
import Clases.Venta;
import java.awt.HeadlessException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;

/**
 *
 * @author Steve Alvarado
 */
public class PantallaPedido extends javax.swing.JDialog {

    DefaultTableModel table;
    private int indice, codigoPedido = 0;
    private final VentanaPrincipal parent;
    private double subTotal = 0;
    private final String[] arrayColumnas = {"Código", "Nombre Producto", "Cantidad", "Precio(₡)"};

    /**
     * Creates new form PantallaCliente
     *
     * @param parent
     * @param modal
     */
    public PantallaPedido(VentanaPrincipal parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.parent = parent;
        llenarTabla();
        noEditarTabla();
        llenarComboBox();
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-carrito-de-compras-32.png")).getImage());
        setTitle("Agregar Pedidos");
        //Evita que el spinner se pueda editar desde el teclado
        ((JSpinner.DefaultEditor) cantidadComprar.getEditor()).getTextField().setEditable(false);
    }

    private void noEditarTabla() {
        for (int i = 0; i < tablaProductos.getColumnCount(); i++) {
            Class<?> col_class = tablaProductos.getColumnClass(i);
            tablaProductos.setDefaultEditor(col_class, null);
        }
    }

    private void llenarTabla() {

        DefaultTableModel table1 = new DefaultTableModel();
        table1.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaProductos.getColumnCount()];
        //Recorrer el contenido del ArrayList
        for (Producto producto : parent.principal.getInventario()) {
            //Añadir cada elemento del ArrayList en la tabla
            columna[0] = producto.getCodigoProducto();
            columna[1] = producto.getNombreProducto();
            columna[2] = producto.getCantidadDisponible();
            columna[3] = producto.getPrecio();

            //Añadimos las columnas a la tabla
            table1.addRow(columna);
        }
        tablaProductos.setModel(table1);
    }

    private void llenarComboBox() {
        for (Cliente cliente : parent.principal.getClientes()) {
            String nombre = cliente.getNombre() + " " + cliente.getApellido();
            comboBoxCliente.addItem(nombre);
        }

    }

    private int validarCantidad(int codigo, int cantidadComprar, int estado) {
        int cantidad = 0, cantidadDisponible;
        //Busca en el inventario 
        for (int i = 0; i < parent.principal.getInventario().size(); i++) {
            //Guarda la cantidad disponible del producto a comprar
            if (parent.principal.getInventario().get(i).getCodigoProducto() == codigo) {
                cantidadDisponible = parent.principal.getInventario().get(i).getCantidadDisponible();
                if (estado == 1) {
                    //Se resta la cantidad disponible con la que desea comprar y se le indica el nuevo disponible al producto
                    cantidad = cantidadDisponible - cantidadComprar;
                } else if (estado == 2) {
                    cantidad = cantidadDisponible + cantidadComprar;
                }

                //Se asigna el nuevo disponible al inventario
                parent.principal.getInventario().get(i).setCantidadDisponible(cantidad);
            }
        }
        parent.principal.guardarMemoria();
        return cantidad;
    }

    private void limpiarTabla() {
        table.setRowCount(0);
        cantidadComprar.setValue(0);
        total.setText("_____");
        comboBoxCliente.setSelectedIndex(0);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        comboBoxCliente = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPedido = new javax.swing.JTable();
        botonAgregar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        botonGuardar = new javax.swing.JButton();
        botonConfirmar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        cantidadComprar = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        comboBoxCliente.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione el nombre del cliente:" }));
        comboBoxCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxClienteActionPerformed(evt);
            }
        });

        tablaPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nombre", "Cantidad", "Precio Unitario", "Precio Total"
            }
        ));
        jScrollPane1.setViewportView(tablaPedido);

        botonAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-agregar-a-carrito-de-compras-16.png"))); // NOI18N
        botonAgregar.setText("Agregar producto");
        botonAgregar.setToolTipText("");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        botonEliminar.setText("Eliminar producto");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Cantidad", "Precio ()"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tablaProductos);
        if (tablaProductos.getColumnModel().getColumnCount() > 0) {
            tablaProductos.getColumnModel().getColumn(0).setResizable(false);
            tablaProductos.getColumnModel().getColumn(1).setResizable(false);
            tablaProductos.getColumnModel().getColumn(2).setResizable(false);
            tablaProductos.getColumnModel().getColumn(3).setResizable(false);
        }

        botonGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-guardar-16.png"))); // NOI18N
        botonGuardar.setText("Guardar");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-casilla-de-verificación-marcada-16.png"))); // NOI18N
        botonConfirmar.setText("Confirmar");
        botonConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConfirmarActionPerformed(evt);
            }
        });

        botonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-cerrar-ventana-16.png"))); // NOI18N
        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Cantidad");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("TOTAL: ₡");

        total.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        total.setText("_____");

        cantidadComprar.setModel(new javax.swing.SpinnerNumberModel(0, 0, 999, 1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(botonAgregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonEliminar)
                .addGap(45, 45, 45))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(botonConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cantidadComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(total)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cantidadComprar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAgregar)
                    .addComponent(botonEliminar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(total))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonGuardar)
                    .addComponent(botonConfirmar)
                    .addComponent(botonCancelar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        try {
            ArrayList pedido = new ArrayList();
            final String[] columnasPedido = {"Código", "Nombre Producto", "Cantidad", "Precio Unitario(₡)", "Monto Total"};
            //Guarda la posicion del producto seleccionado
            indice = tablaProductos.getSelectedRow();
            int cantidad = Integer.parseInt(cantidadComprar.getValue().toString());
            int codigoProducto = Integer.parseInt(tablaProductos.getValueAt(indice, 0).toString());

            //Valida que la cantidad sea mayor a 0
            if (Integer.parseInt(cantidadComprar.getValue().toString()) == 0) {
                JOptionPane.showMessageDialog(null, "Digite la cantidad deseada");

            } else if (validarCantidad(codigoProducto, cantidad, 1) < 0) { //Valida disponibilidad en el inventario
                JOptionPane.showMessageDialog(null, "Digite una cantidad valida");
            } //Si el indice es igual a 1 implica que el usuario selecciono un producto de la tabla
            else if (tablaProductos.getSelectedRowCount() == 1) {
                table = (DefaultTableModel) tablaProductos.getModel();
                //Guarda el valor de cada columna de la fila seleccionada
                pedido.add(String.valueOf(tablaProductos.getValueAt(indice, 0))); //Codigo Producto
                pedido.add(String.valueOf(tablaProductos.getValueAt(indice, 1))); //Nombre Producto
                pedido.add(cantidadComprar.getValue().toString());                            //Cantidad a comprar
                pedido.add(String.valueOf(tablaProductos.getValueAt(indice, 3)));//Precio

                table = (DefaultTableModel) tablaPedido.getModel();

                //Agrega las columnas a la tabla pedidos
                table.setColumnIdentifiers(columnasPedido);

                Object[] compra = new Object[tablaPedido.getColumnCount()];
                //Pasa la columna selecciona de la tabla producto a la tabla pedidos
                compra[0] = pedido.get(0).toString();
                compra[1] = pedido.get(1).toString();
                compra[2] = pedido.get(2).toString();
                compra[3] = pedido.get(3).toString();
                compra[4] = Double.parseDouble(pedido.get(3).toString()) * Integer.parseInt(pedido.get(2).toString());//Monto total
                table.addRow(compra);

                //Va sumando el precio de los productos y se muestra en la pantalla
                subTotal += Double.parseDouble(compra[4].toString());
                total.setText(String.valueOf(subTotal));

                //Limpia la caja de texto de cantidad
                cantidadComprar.setValue(0);

                llenarTabla();

                //Si el indice es mayor a 1 implica que el usuario selecciono mas de un producto de la tabla
            } else if (tablaProductos.getSelectedRowCount() > 1) {
                JOptionPane.showMessageDialog(null, "Seleccione solo un producto a la vez");

                //Si el indice es menor a 1 implica que el usuario no selecciono ningun producto de la tabla
            } else if (tablaProductos.getSelectedRowCount() < 1) {
                JOptionPane.showMessageDialog(null, "Seleccione su producto ");
            }
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        if (tablaPedido.getRowCount() > 0) {
            JOptionPane.showMessageDialog(null, "Tiene productos sin guardar o confimar");
        } else {
            this.setVisible(false);
        }

    }//GEN-LAST:event_botonCancelarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        try {
            if (tablaPedido.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Debe agregar al menos un producto para guardar el pedido");
            } 
            else {
                //Guarda la posicion del cliente que realiza el pedido
                int indiceCliente = comboBoxCliente.getSelectedIndex();

                if (indiceCliente == 0) {
                    JOptionPane.showMessageDialog(null, "Seleccione un cliente ");

                } else {
                    if (parent.principal.getPedidos().isEmpty()) {
                        codigoPedido = 1;
                    } else {
                        int codUltimoPedido = parent.principal.getPedidos().get(parent.principal.getPedidos().size() - 1).getCodigo();
                        codigoPedido = codUltimoPedido + 1;
                    }

                    Pedido pedido = new Pedido();
                    pedido.setCodigo(codigoPedido);
                    pedido.setEstado(1);

                    //Recorre la tabla del posible pedido del cliente
                    for (int i = 0; i < tablaPedido.getRowCount(); i++) {

                        //Variables para guardar el valor de las columnas
                        int codigo = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(i, 0)));
                        String nombre = String.valueOf(tablaPedido.getValueAt(i, 1));
                        int cantidad = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(i, 2)));
                        String precio = String.valueOf(tablaPedido.getValueAt(i, 3));

                        //Agrega cada producto al pedido
                        pedido.agregarProducto(codigo, cantidad, nombre, Integer.parseInt(precio.substring(0, precio.length() - 2)));
                    }
                    llenarTabla();
                    //Agrega el pedido al ArrayList de Pedidos 
                    parent.principal.agregar(pedido);

                    //Asigna el pedido al cliente que le corresponde
                    parent.principal.getClientes().get(indiceCliente - 1).setPedido(pedido);

                    parent.principal.guardarMemoria();

                    JOptionPane.showMessageDialog(null, "¡Pedido Guardado!");

                }
                tablaProductos.clearSelection();
                limpiarTabla();
                subTotal = 0.0;

            }
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        try {

            //Si es igual a 1 implica que el usuario selecciono un producto de la tabla
            if (tablaPedido.getSelectedRowCount() == 1) {
                int codigo = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(tablaPedido.getSelectedRow(), 0)));
                int cantidad = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(tablaPedido.getSelectedRow(), 2)));

                //Devuelve la cantidad al inventario
                validarCantidad(codigo, cantidad, 2);

                //Resta el precio de los productos eliminados y se muestra en la pantalla
                subTotal -= Double.parseDouble(String.valueOf(tablaPedido.getValueAt(tablaPedido.getSelectedRow(), 4)));
                total.setText(String.valueOf(subTotal));

                table = (DefaultTableModel) tablaPedido.getModel();
                table.removeRow(tablaPedido.getSelectedRow());

                llenarTabla();
                //Si el indice es mayor a 1 implica que el usuario selecciono mas de un producto de la tabla
            } else if (tablaProductos.getSelectedRowCount() > 1) {
                JOptionPane.showMessageDialog(null, "Seleccione solo un producto a la vez");

                //Si el indice es menor a 1 implica que el usuario no selecciono ningun producto de la tabla
            } else if (tablaProductos.getSelectedRowCount() < 1) {
                JOptionPane.showMessageDialog(null, "Seleccione su producto ");
            }
        } catch (NumberFormatException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void comboBoxClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxClienteActionPerformed

    private void botonConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConfirmarActionPerformed
        try {
            if (tablaPedido.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Debe agregar al menos un producto para confirmar el pedido");
            } else {
//           Guarda la posicion del cliente que realiza el pedido
                int indiceCliente = comboBoxCliente.getSelectedIndex();

                if (indiceCliente == 0) {
                    JOptionPane.showMessageDialog(null, "Seleccione un cliente ");

                } else {
                    if (parent.principal.getPedidos().isEmpty()) {
                        codigoPedido = 1;
                    } else {
                        int codUltimoPedido = parent.principal.getPedidos().get(parent.principal.getPedidos().size() - 1).getCodigo();
                        codigoPedido = codUltimoPedido + 1;
                    }
                    Venta venta = new Venta();

                    venta.setCodigo(codigoPedido);
                    venta.setEstado(2);
                    venta.setTotal(subTotal);
                    
                    Pedido pedido = new Pedido();
                    pedido.setCodigo(codigoPedido);
                    pedido.setEstado(2);

                    //Recorre la tabla del posible pedido del cliente
                    for (int i = 0; i < tablaPedido.getRowCount(); i++) {

                        //Variables para guardar el valor de las columnas
                        int codigo = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(i, 0)));
                        String nombre = String.valueOf(tablaPedido.getValueAt(i, 1));
                        int cantidad = Integer.parseInt(String.valueOf(tablaPedido.getValueAt(i, 2)));
                        String precio = String.valueOf(tablaPedido.getValueAt(i, 3));
                        
                        venta.agregarProducto(codigo, cantidad, nombre, Integer.parseInt(precio.substring(0, precio.length() - 2)));
                        pedido.agregarProducto(codigo, cantidad, nombre, Integer.parseInt(precio.substring(0, precio.length() - 2)));
                    }
                    llenarTabla();
                    //Agrega el pedido a ventas 
                    parent.principal.agregar(venta);
                    
                    //Lo agrega a pedidos
                    parent.principal.agregar(pedido);

                    //Asigna el pedido al cliente que le corresponde
                    parent.principal.getClientes().get(indiceCliente - 1).setPedido(venta);

                    parent.principal.guardarMemoria();
                    
                    JOptionPane.showMessageDialog(null, "¡Pedido Confirmado!");
                }
                tablaProductos.clearSelection();
                limpiarTabla();
                subTotal = 0.0;

            }
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonConfirmarActionPerformed

    /**
     * @param args the command line arguments
     *///<editor-
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
//        fold defaultstate="collapsed" desc=" Look and feel setting code (optional) "
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PantallaPedido dialog = new PantallaPedido(new VentanaPrincipal(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonConfirmar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JSpinner cantidadComprar;
    private javax.swing.JComboBox comboBoxCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tablaPedido;
    private javax.swing.JTable tablaProductos;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
