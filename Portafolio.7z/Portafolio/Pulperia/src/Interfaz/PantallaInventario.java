/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import Clases.Pedido;
import Clases.Producto;
import java.awt.HeadlessException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sarahi
 */
public class PantallaInventario extends javax.swing.JDialog {

    private int indice;
    
    private VentanaPrincipal parent;
    private final String[] arrayColumnas = {"Código", "Nombre Producto", "Cantidad", "Precio(₡)"};

    /**
     * Creates new form PantallaInventario
     *
     * @param parent
     * @param modal
     * @param valor
     */
    public PantallaInventario(VentanaPrincipal parent, boolean modal, int valor) {
        super(parent, modal);
        initComponents();
        this.parent = parent;
        llenarTabla();
        noEditarTabla();
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-bolsa-de-la-compra-32.png")).getImage());
        switch (valor) {
            case 1:
                setTitle("Agregar Productos");
                botonGuardar.setVisible(false);
                botonEliminar.setVisible(false);
                break;
            case 2:
                setTitle("Modificar Productos");
                botonAgregar.setVisible(false);
                botonEliminar.setVisible(false);
                codigoProducto.enable(false);
                nombreProducto.enable(false);
                break;
            case 3:
                setTitle("Eliminar Productos");
                botonGuardar.setVisible(false);
                botonAgregar.setVisible(false);
                label1.setVisible(false);
                label2.setVisible(false);
                label3.setVisible(false);
                label4.setVisible(false);
                codigoProducto.setVisible(false);
                nombreProducto.setVisible(false);
                precio.setVisible(false);
                cantidad.setVisible(false);
                break;
            default:
                break;
        }

    }

    private void noEditarTabla() {
        for (int i = 0; i < tablaProductos.getColumnCount(); i++) {
            Class<?> col_class = tablaProductos.getColumnClass(i);
            tablaProductos.setDefaultEditor(col_class, null);
        }
    }

    private void llenarTabla() {
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaProductos.getColumnCount()];
        //Recorrer el contenido del ArrayList
        for (Producto productos : parent.principal.getInventario()) {
            //Añadir cada elemento del ArrayList en el TableModel
            columna[0] = productos.getCodigoProducto();
            columna[1] = productos.getNombreProducto();
            columna[2] = productos.getCantidadDisponible();
            columna[3] = productos.getPrecio();

            //Añadimos las columnas a la tabla
            table.addRow(columna);
        }
        tablaProductos.setModel(table);
    }

    public void limpiar() {
        nombreProducto.setText("");
        cantidad.setText("");
        codigoProducto.setText("");
        precio.setText("");
    }
    
    public boolean buscarProducto(int codigo){
        boolean estado = false;
        for(Pedido pedido: parent.principal.getPedidos()){
            for(int i = 0; i < pedido.getProductos().size(); i++){
                if(pedido.getProductos().get(i).getCodigoProducto() == codigo){
                    estado = true;
                }
            }
        }
        return estado;
    }

    public boolean validarCodigoProducto(int codigo){
        boolean encontrado = false;
        for(Producto producto: parent.principal.getInventario()){
            if(producto.getCodigoProducto() == codigo){
                encontrado = true;
            }
        }
        
        return encontrado;
    }
    
    private void seleccionar(){
        if(tablaProductos.getSelectedRowCount()==1){
            codigoProducto.setText(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 0).toString());
            nombreProducto.setText(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 1).toString());
            cantidad.setText(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 2).toString());
            precio.setText(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 3).toString());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nombreProducto = new javax.swing.JTextField();
        codigoProducto = new javax.swing.JTextField();
        botonAgregar = new javax.swing.JButton();
        precio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        label1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        label4 = new javax.swing.JLabel();
        botonCancelar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        cantidad = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        botonAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-agregar-a-carrito-de-compras-16.png"))); // NOI18N
        botonAgregar.setText("Agregar");
        botonAgregar.setToolTipText("");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Cantidad", "Precio(₡)"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaProductos);

        label1.setText("Nombre Producto");

        label2.setText("Código");

        label3.setText("Cantidad");

        label4.setText("Precio");

        botonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-cerrar-ventana-16.png"))); // NOI18N
        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        botonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        botonEliminar.setLabel("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        botonGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-guardar-16.png"))); // NOI18N
        botonGuardar.setText("Guardar");
        botonGuardar.setToolTipText("");
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(codigoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(label1)
                            .addComponent(nombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(68, 68, 68)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label3)
                            .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label4)
                            .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(botonEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                            .addComponent(botonAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1)
                    .addComponent(label2)
                    .addComponent(label4)
                    .addComponent(label3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(nombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(codigoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(botonAgregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonGuardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonEliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonCancelar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        
            if (tablaProductos.getSelectedRowCount() == 1) {
                int codigo = Integer.parseInt(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 0).toString());

                if (buscarProducto(codigo) == false) {
                    Producto producto = new Producto();
                    parent.principal.eliminar(producto, tablaProductos.getSelectedRow());

                    JOptionPane.showMessageDialog(null, "¡Producto eliminado!");
                    llenarTabla();

                } else {
                    JOptionPane.showMessageDialog(null, "El producto tiene pedido(s) guardado(s)");
                }

                //Guarda los datos en el txt
                parent.principal.guardarMemoria();
                
            }else if(tablaProductos.getSelectedRowCount() == 0){
                
                JOptionPane.showMessageDialog(null, "Seleccione un producto");
                
            }else if (tablaProductos.getSelectedRowCount() > 1){
                
                JOptionPane.showMessageDialog(null, "Solo puede eliminar un producto a la vez");
            }
            
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        try {
            int codigo = Integer.parseInt(codigoProducto.getText());
            
            if (validarCodigoProducto(codigo)) {
                
                JOptionPane.showMessageDialog(null, "El código " + codigo + " ya ha sido utilizado");
            } else {
                
                Producto producto = new Producto();
                producto.setCodigoProducto(Integer.parseInt(codigoProducto.getText()));
                producto.setCantidadDisponible(Integer.parseInt(cantidad.getText()));
                producto.setNombreProducto(nombreProducto.getText());
                producto.setPrecio(Double.parseDouble(precio.getText()));

                parent.principal.agregar(producto);

                JOptionPane.showMessageDialog(null, "¡Producto agregado exitosamente!");

                llenarTabla();
                limpiar();

                parent.principal.guardarMemoria();
            }

        } catch (NullPointerException | NumberFormatException ex) {
            
            JOptionPane.showMessageDialog(null, "No se permiten espacios en blanco");
            
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }

    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        try {
            indice = tablaProductos.getSelectedRow();
            if (nombreProducto.getText().isEmpty() || codigoProducto.getText().isEmpty() ||
                    cantidad.getText().isEmpty() || precio.getText().isEmpty()) {
                
                JOptionPane.showMessageDialog(null, "Favor completar todos los espacios");
            
            }else {
                Producto productoModicado = new Producto();
                
                productoModicado.setCodigoProducto(Integer.parseInt(codigoProducto.getText()));
                productoModicado.setCantidadDisponible(Integer.parseInt(cantidad.getText()));
                productoModicado.setNombreProducto(nombreProducto.getText());
                productoModicado.setPrecio(Double.parseDouble(precio.getText()));

                parent.principal.modificar(productoModicado, indice);

                llenarTabla();
                limpiar();

                parent.principal.guardarMemoria();

                JOptionPane.showMessageDialog(null, "¡Producto modificado!");
            }
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void tablaProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProductosMouseClicked
        if(botonGuardar.isVisible()){
           seleccionar(); 
        }
    }//GEN-LAST:event_tablaProductosMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaInventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaInventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaInventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaInventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PantallaInventario dialog = new PantallaInventario(new VentanaPrincipal(), true, 0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField codigoProducto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JLabel label4;
    private javax.swing.JTextField nombreProducto;
    private javax.swing.JTextField precio;
    private javax.swing.JTable tablaProductos;
    // End of variables declaration//GEN-END:variables
}
