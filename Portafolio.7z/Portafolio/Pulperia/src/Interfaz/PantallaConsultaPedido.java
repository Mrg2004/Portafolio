/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;
import Clases.Pedido;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Clases.Cliente;
import Clases.Producto;
import Clases.Venta;
import java.awt.HeadlessException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
/**
 *
 * @author Sarahi
 */
public class PantallaConsultaPedido extends javax.swing.JDialog {

    private VentanaPrincipal parent;
    
    private  final String[] arrayColumnas = {"Código Producto", "Nombre Producto", "Cantidad","Precio(₡)", "Código Pedido", "Estado"};
    
    public PantallaConsultaPedido(VentanaPrincipal parent, boolean modal, int indice) {
        super(parent, modal);
        initComponents();
        this.parent = parent;
        buttonGroup.add(no);
        buttonGroup.add(si);
        llenarTabla();
        noEditarTabla();
        llenarComboBox();
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-carrito-de-compras-32.png")).getImage());
        //Evita que el spinner se pueda editar desde el teclado
        ((JSpinner.DefaultEditor) cantidad.getEditor()).getTextField().setEditable(false);
        switch (indice) {
            case 2:
                setTitle("Consultar Pedidos");
                jLabel1.setVisible(false);
                si.setVisible(false);
                no.setVisible(false);
                botonModificar.setVisible(false);
                botonEliminar.setVisible(false);
                labelCantidad.setVisible(false);
                cantidad.setVisible(false);
                break;
            case 3:
                setTitle("Modificar Pedidos");
                botonEliminar.setVisible(false);
                break;
            case 4:
                setTitle("Eliminar Pedidos");
                jLabel1.setVisible(false);
                si.setVisible(false);
                no.setVisible(false);
                botonModificar.setVisible(false);
                labelCantidad.setVisible(false);
                cantidad.setVisible(false);
            default:
                break;
        }
    }
    
    private void noEditarTabla() {
        for (int i = 0; i < tablaPedidos.getColumnCount(); i++) {
            Class<?> col_class = tablaPedidos.getColumnClass(i);
            tablaPedidos.setDefaultEditor(col_class, null);
        }
    }

    private void llenarTabla() {
        
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaPedidos.getColumnCount()];
        //Recorrer el contenido del ArrayList
        for (Pedido pedido : parent.principal.getPedidos()) {
            for (int i = 0; i < pedido.getProductos().size(); i++) {
                //Añadir cada elemento del ArrayList en la tabla
                columna[0] = pedido.getProductos().get(i).getCodigoProducto();
                columna[1] = pedido.getProductos().get(i).getNombreProducto();
                columna[2] = pedido.getProductos().get(i).getCantidadDisponible();
                columna[3] = pedido.getProductos().get(i).getPrecio();
                columna[4] = pedido.getCodigo();
                if (pedido.isEstado() == 1) {
                    columna[5] = "Guardado";
                } else {
                    columna[5] = "Confirmado";
                }
                //Añadimos las columnas a la tabla
                table.addRow(columna);
            }

        }
        tablaPedidos.setModel(table);
    }
    
    private void llenarComboBox(){
        for (Cliente cliente: parent.principal.getClientes() ){
            String nombre = "ID: "+ cliente.getID()+"-"+cliente.getNombre() + " " + cliente.getApellido();
            comboBoxCliente.addItem(nombre);
        }
    }
    
    private void seleccionar(){
        if(tablaPedidos.getSelectedRowCount()==1){
            
            cantidad.setValue(Integer.parseInt(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 2).toString()));
                    
        }
    }
    
    private void mostrarPedidoxCliente(int posicion) {
        
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaPedidos.getColumnCount()];
  
        //Recorre los pedidos que tiene el cliente
        for(Pedido pedido: parent.principal.getClientes().get(posicion).getPedido())  {
            //Recorre los productos que tiene cada pedido
            for(Producto producto: pedido.getProductos()) {
                //Agrega el valor de cada producto a la columna correspondiente
                columna[0] = producto.getCodigoProducto();
                columna[1] = producto.getNombreProducto();
                columna[2] = producto.getCantidadDisponible();
                columna[3] = producto.getPrecio();
                columna[4] = pedido.getCodigo();
                if ( pedido.isEstado() == 1) {
                    columna[5] = "Guardado";
                } else if (pedido.isEstado() == 2) {
                    columna[5] = "Confirmado";
                } else if(( pedido.isEstado() == 3)){
                    columna[5] = "Pagado";
                }
                //Añadimos las columnas a la tabla
                table.addRow(columna);
            }
        }
        tablaPedidos.setModel(table);
    }
    
    public boolean validarCantidad(int codigo, int cantidad){
        boolean valido = false;
        
        for(Producto producto: parent.principal.getInventario()){
            if(producto.getCodigoProducto()== codigo){
                if(cantidad<producto.getCantidadDisponible()){
                    valido = true;
                    break;
                }
            }
        }
        
        return valido;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPedidos = new javax.swing.JTable();
        comboBoxCliente = new javax.swing.JComboBox();
        botonBuscar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        labelCantidad = new javax.swing.JLabel();
        botonModificar = new javax.swing.JButton();
        cantidad = new javax.swing.JSpinner();
        jLabel1 = new javax.swing.JLabel();
        si = new javax.swing.JRadioButton();
        no = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tablaPedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Producto", "Nombre", "Cantidad", "Precio ()", "Código Pedido", "Estado"
            }
        ));
        tablaPedidos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPedidosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPedidos);

        comboBoxCliente.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione el nombre del cliente:" }));

        botonBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-búsqueda-16.png"))); // NOI18N
        botonBuscar.setText("Buscar");
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });

        botonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        botonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-cerrar-ventana-16.png"))); // NOI18N
        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        labelCantidad.setText("Cantidad");

        botonModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-actualizaciones-disponibles-16.png"))); // NOI18N
        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        cantidad.setModel(new javax.swing.SpinnerNumberModel(0, 0, 999, 1));

        jLabel1.setText("¿Desea confirmar el pedido?");

        si.setText("Sí");

        no.setText("No");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(17, 17, 17)
                                        .addComponent(si)
                                        .addGap(18, 18, 18)
                                        .addComponent(no))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelCantidad)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonModificar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonBuscar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonCancelar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelCantidad)
                            .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(botonBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonEliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonModificar))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(si)
                            .addComponent(no))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCancelar)
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void tablaPedidosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPedidosMouseClicked
        seleccionar();
    }//GEN-LAST:event_tablaPedidosMouseClicked

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        try {
            //Valida que solo haya una fila seleccionada para eliminar
            if (tablaPedidos.getSelectedRowCount() == 1) {
                int codigoPedido = Integer.parseInt(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 4).toString());

                //Elimina el pedido de la lista pedidos
                Pedido pedido = new Pedido();
                for (int i = 0; i < parent.principal.getPedidos().size(); i++) {
                    if (parent.principal.getPedidos().get(i).getCodigo() == codigoPedido) {

                        parent.principal.eliminar(pedido, i);

                    }
                }
                
                //Elimina la venta de la lista ventas
                Venta venta = new Venta();
                for (int i = 0; i < parent.principal.getVentas().size(); i++) {
                    if(parent.principal.getVentas().get(i).getCodigo()== codigoPedido){
                        parent.principal.eliminar(venta, i);
                    }
                }
                
                //Elimina el pedido del cliente correspondiente
                for (Cliente cliente : parent.principal.getClientes()) {
                    //Recorre todos los pedidos que tiene el cliente
                    for (int i = 0; i < cliente.getPedido().size(); i++) {
                        //Verifica que el codigo de pedido coincida con el que se quiere eliminar
                        if (cliente.getPedido().get(i).getCodigo() == codigoPedido) {
                            
                            //Recorre los productos que tiene el pedido para devolver la cantidad al inventario
                            for (int j = 0; j < cliente.getPedido().get(i).getProductos().size(); j++) {
                                int cantidadPedida = cliente.getPedido().get(i).getProductos().get(j).getCantidadDisponible();
                                int codigoProducto = cliente.getPedido().get(i).getProductos().get(j).getCodigoProducto();
                                //Recorre el inventario de todos los productos
                                for (int k = 0; k < parent.principal.getInventario().size(); k++) {
                                    
                                    //Compara los codigos de los productos para que la cantidad a devolver
                                    //se le asigne al producto correcto
                                    if (parent.principal.getInventario().get(k).getCodigoProducto() == codigoProducto) {
                                        int cantidadActual = parent.principal.getInventario().get(k).getCantidadDisponible();
                                        int nuevoDisponible = cantidadActual + cantidadPedida;
                                        //Devuelve la cantidad que se iba a comprar a la cantidad Disponible
                                        parent.principal.getInventario().get(k).setCantidadDisponible(nuevoDisponible);
                                        
                                        JOptionPane.showMessageDialog(null, "Devolución: "+cantidadPedida + " unds"
                                                                          + "\nCodigo Producto: "+parent.principal.getInventario().get(k).getCodigoProducto()
                                                                          + "\nNombre Producto: "+parent.principal.getInventario().get(k).getNombreProducto());
                                    }
                                }
                            }
                            //Elimina el pedido asignado al cliente
                            cliente.getPedido().remove(i);
                        }
                    }
                }

                JOptionPane.showMessageDialog(null, "¡Pedido eliminado!");
                
                //Actualiza la tabla
                llenarTabla();
                comboBoxCliente.setSelectedIndex(0);
                
                //Guarda los datos en el txt
                parent.principal.guardarMemoria();
            }else if(tablaPedidos.getSelectedRowCount() < 1){
                 JOptionPane.showMessageDialog(null, "Seleccione el pedido a eliminar");
            }else if(tablaPedidos.getSelectedRowCount() > 1){
                 JOptionPane.showMessageDialog(null, "Seleccione un pedido a la vez");
            }


        } catch (NumberFormatException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        //Guarda la posicion del cliente a buscar
        try {
            int indiceCliente = comboBoxCliente.getSelectedIndex();

            if (indiceCliente == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione un cliente ");
            } else {
                mostrarPedidoxCliente(indiceCliente - 1);

            }
            if (tablaPedidos.getRowCount() > 0) {
                JOptionPane.showMessageDialog(null, "¡Pedido(s) encontrado!");
            } else {
                JOptionPane.showMessageDialog(null, "El cliente no tiene pedidos aún");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }//GEN-LAST:event_botonBuscarActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        try {
            if(!si.isSelected() && !no.isSelected()){
                JOptionPane.showMessageDialog(null, "Seleccione si desea  o no confirmar el pedido");
            }else if(String.valueOf(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 5)).equals("Pagado")){
                JOptionPane.showMessageDialog(null, "No se puede modificar una venta pagada");
            }else if (tablaPedidos.getSelectedRowCount() == 1) {
                int codigoPedido = Integer.parseInt(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 4).toString());
                int nuevaCantidad = Integer.parseInt(cantidad.getValue().toString());
                int cantidadAnterior = Integer.parseInt(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 2).toString());
                int codigoProducto = Integer.parseInt(tablaPedidos.getValueAt(tablaPedidos.getSelectedRow(), 0).toString());
                boolean existe = false;
                
                if (validarCantidad(codigoProducto, nuevaCantidad)) {

                    for (Cliente cliente : parent.principal.getClientes()) {
                        //Obtiene el o los pedidos de cada cliente
                        for (int i = 0; i < cliente.getPedido().size(); i++) {
                            //Valida que el pedido seleccionado sea el correcto
                            if (cliente.getPedido().get(i).getCodigo() == codigoPedido) {
                                //Recorre los productos del pedido seleccionado
                                for (Producto productoCliente : cliente.getPedido().get(i).getProductos()) {

                                    if (productoCliente.getCodigoProducto() == codigoProducto) {

                                        //Asigna la nueva cantidad disponible al pedido del cliente
                                        productoCliente.setCantidadDisponible(nuevaCantidad);

                                    }
                                }
                            }
                        }
                    }

                    //Recorre el inventario de todos los productos 
                    //para modificar la cantidad en el inventario
                    for (Producto productoInventario : parent.principal.getInventario()) {

                        if (productoInventario.getCodigoProducto() == codigoProducto) {

                            //Guarda la cantidad disponible del producto
                            int disponible = productoInventario.getCantidadDisponible();

                            //Verifica si la cantidad a modificar es mayor o menor a la actual
                            if (nuevaCantidad >= cantidadAnterior) {
                                productoInventario.setCantidadDisponible(disponible - (nuevaCantidad - cantidadAnterior));

                            } else {
                                productoInventario.setCantidadDisponible(disponible + (cantidadAnterior - nuevaCantidad));

                            }
                        }
                    }

                    //En caso que el pedido se confirme como venta
                    for (Pedido pedido : parent.principal.getPedidos()) {
                        if (pedido.getCodigo() == codigoPedido) {
                            ArrayList listaProductos = pedido.getProductos();
                            double total = 0;
                            double subtotal;
                            //Obtiene el total a pagar por el pedido
                            for (Producto producto : pedido.getProductos()) {
                                subtotal = producto.getCantidadDisponible() * producto.getPrecio();
                                total += subtotal;
                            }

                            if (si.isSelected()) {
                                //Busca si el pedido ya habia sido confirmado anteriormente
                                for (Venta venta2 : parent.principal.getVentas()) {
                                    if (venta2.getCodigo() == codigoPedido) {
                                        venta2.setEstado(2);
                                        
                                        venta2.setTotal(total);
                                        existe = true;
                                    }
                                }
                                //Si el pedido no estaba confirmado anteriormente
                                if(existe == false){
                                    //Instancia de venta para agregarla a su respectiva lista
                                    Venta venta = new Venta();
                                    venta.setCodigo(codigoPedido);
                                    venta.setEstado(2);
                                    venta.setTotal(total);
                                    venta.setProductos(listaProductos);

                                    parent.principal.agregar(venta);
                                }

                                pedido.setEstado(2);
                                break;
                            } 
                            //Si el cliente no desea confirmar el pedido
                            else if (no.isSelected()) {
                                Venta venta = new Venta();
                                for (int i = 0; i < parent.principal.getVentas().size(); i++) {
                                    if (parent.principal.getVentas().get(i).getCodigo() == codigoPedido) {
                                        parent.principal.getVentas().get(i).setEstado(1);
                                        parent.principal.eliminar(venta, i);
                                    }
                                }
                                pedido.setEstado(1);
                            }
                        }
                    }
                    JOptionPane.showMessageDialog(null, "¡Pedido modificado!");
                    
                    //Guarda los datos en el txt
                    parent.principal.guardarMemoria();
                } else {
                    JOptionPane.showMessageDialog(null, "¡No hay suficientes unidades disponibles en el inventario!");
                }

                //Actualiza la tabla
                llenarTabla();
                comboBoxCliente.setSelectedIndex(0);
                cantidad.setValue(0);
                tablaPedidos.clearSelection();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonModificarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaConsultaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaConsultaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaConsultaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaConsultaPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PantallaConsultaPedido dialog = new PantallaConsultaPedido(new VentanaPrincipal(), true,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonModificar;
    private javax.swing.ButtonGroup buttonGroup;
    private javax.swing.JSpinner cantidad;
    private javax.swing.JComboBox comboBoxCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCantidad;
    private javax.swing.JRadioButton no;
    private javax.swing.JRadioButton si;
    private javax.swing.JTable tablaPedidos;
    // End of variables declaration//GEN-END:variables
}
