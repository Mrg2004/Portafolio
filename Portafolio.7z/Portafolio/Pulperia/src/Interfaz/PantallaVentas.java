
package Interfaz;

import Clases.Cliente;
import Clases.Pedido;
import Clases.Producto;
import Clases.Venta;
import java.awt.HeadlessException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author antonio
 */
public class PantallaVentas extends javax.swing.JDialog {
    private VentanaPrincipal parent;
    private final String[] arrayColumnas = {"Código","MontoTotal","Estado"};
    
    public PantallaVentas(VentanaPrincipal parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.parent = parent;
        llenarTabla();
        noEditarTabla();
        llenarComboBox();
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-carrito-de-compras-32.png")).getImage());
        setTitle("Ventas");
    }

    private void noEditarTabla() {
        for (int i = 0; i < tablaVentas.getColumnCount(); i++) {
            Class<?> col_class = tablaVentas.getColumnClass(i);
            tablaVentas.setDefaultEditor(col_class, null);
        }
    }
    
    private void llenarTabla(){
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaVentas.getColumnCount()];
        for (Venta venta : parent.principal.getVentas()) {
            columna[0] = venta.getCodigo();
            columna[1] = venta.getTotal();
            if(venta.isEstado() == 2){
                columna[2] = "Confirmado";
            }else if(venta.isEstado() == 3){
                columna[2] = "Pagado";
            }
            
            table.addRow(columna);
        }
        tablaVentas.setModel(table);
    }
    

    private void llenarComboBox(){
        for (Cliente cliente: parent.principal.getClientes()) {
            String nombre = cliente.getID()+"-"+cliente.getNombre()+"-"+cliente.getApellido();
            comboBoxCliente.addItem(nombre);
        }
    }
    
    private void mostrarPedidoxCliente(int idCliente) {
        
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaVentas.getColumnCount()];
  
        
        //Recorre los pedidos que tiene el cliente
        for(Pedido pedido : parent.principal.getClientes().get(idCliente).getPedido()) {
            for (Venta venta : parent.principal.getVentas()) {
                if (pedido.getCodigo() == venta.getCodigo()) {
                    //Agrega el valor de cada producto a la columna correspondiente
                    columna[0] = pedido.getCodigo();
                    columna[1] = venta.getTotal();
                    if (pedido.isEstado() == 2) {
                        columna[2] = "Confirmado";
                    } else if ((pedido.isEstado() == 3)) {
                        columna[2] = "Pagado";
                    }
                    //Añadimos las columnas a la tabla
                    table.addRow(columna);

                }
            }
        }
        tablaVentas.setModel(table);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVentas = new javax.swing.JTable();
        botonSalir = new javax.swing.JButton();
        comboBoxCliente = new javax.swing.JComboBox();
        botonPagar = new javax.swing.JButton();
        botonBuscar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tablaVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Total", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaVentas);

        botonSalir.setBackground(new java.awt.Color(204, 204, 204));
        botonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-cerrar-ventana-16.png"))); // NOI18N
        botonSalir.setText("Cancelar");
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        comboBoxCliente.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Seleccione el nombre del cliente:" }));
        comboBoxCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxClienteActionPerformed(evt);
            }
        });

        botonPagar.setBackground(new java.awt.Color(204, 204, 204));
        botonPagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-caja-registradora-16.png"))); // NOI18N
        botonPagar.setText("Pagar");
        botonPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPagarActionPerformed(evt);
            }
        });

        botonBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-búsqueda-16.png"))); // NOI18N
        botonBuscar.setText("Buscar");
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(botonPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(botonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonSalir)
                    .addComponent(botonPagar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboBoxClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxClienteActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_botonSalirActionPerformed

    private void botonPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPagarActionPerformed
        try {
            if(tablaVentas.getSelectedRowCount() < 1){
                 JOptionPane.showMessageDialog(null, "Seleccione la venta a pagar");
            }else if (tablaVentas.getSelectedRowCount() > 1) {
                JOptionPane.showMessageDialog(null, "No se permite seleccionar mas de una venta");
            }else if(String.valueOf(tablaVentas.getValueAt(tablaVentas.getSelectedRow(), 2)).equals("Pagado")){
                JOptionPane.showMessageDialog(null, "El pedido ya se encuentra pagado");
            }else if (tablaVentas.getSelectedRowCount() == 1) {
                int codigoVenta = Integer.parseInt(String.valueOf(tablaVentas.getValueAt(tablaVentas.getSelectedRow(), 0)));
                for (Pedido pedido : parent.principal.getPedidos()) {
                    if (codigoVenta == pedido.getCodigo()) {
                        pedido.setEstado(3);
                    }
                }

                for (Venta venta : parent.principal.getVentas()) {
                    if (codigoVenta == venta.getCodigo()) {
                        venta.setEstado(3);
                    }
                }

                for (Cliente cliente : parent.principal.getClientes()) {
                    for (int i = 0; i < cliente.getPedido().size(); i++) {
                        if (cliente.getPedido().get(i).getCodigo() == codigoVenta) {
                            cliente.getPedido().get(i).setEstado(3);
                        }
                    }

                }

                parent.principal.guardarMemoria();

                llenarTabla();

                JOptionPane.showMessageDialog(null, "¡Pago realizado exitosamente!");
            }
        } catch (NumberFormatException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_botonPagarActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        //Guarda la posicion del cliente a buscar
        try {
            int indiceCliente = comboBoxCliente.getSelectedIndex();

            if (indiceCliente == 0) {
                JOptionPane.showMessageDialog(null, "Seleccione un cliente ");
            } else {
                mostrarPedidoxCliente(indiceCliente - 1);

            }
            if (tablaVentas.getRowCount() > 0) {
                JOptionPane.showMessageDialog(null, "¡Pedido(s) encontrado(s)!");
            } else {
                JOptionPane.showMessageDialog(null, "El cliente no tiene pedidos confirmados aún");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonBuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PantallaVentas dialog = new PantallaVentas(new VentanaPrincipal(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonPagar;
    private javax.swing.JButton botonSalir;
    private javax.swing.JComboBox comboBoxCliente;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaVentas;
    // End of variables declaration//GEN-END:variables
}
