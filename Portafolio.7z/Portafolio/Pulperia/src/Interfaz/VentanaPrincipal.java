
package Interfaz;

import Clases.Pedido;
import Clases.Principal;
import javax.swing.ImageIcon;


/**
 *
 * @author Sarahi
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    public Principal principal = new Principal();
    
    public VentanaPrincipal() {
        initComponents();
        setVisible(true);
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-pequeña-empresa-64.png")).getImage());
        setTitle("Pulperia");
        //Lee la informacion almacenada del txt
        principal.leerMemoria();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        InventarioMenu = new javax.swing.JMenu();
        agregarProducto = new javax.swing.JMenuItem();
        modificarProducto = new javax.swing.JMenuItem();
        eliminarProducto = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        agregarCliente = new javax.swing.JMenuItem();
        modificarCliente = new javax.swing.JMenuItem();
        eliminarCliente = new javax.swing.JMenuItem();
        Pedido = new javax.swing.JMenu();
        agregarPedido = new javax.swing.JMenuItem();
        consultarPedido = new javax.swing.JMenuItem();
        modificarPedido = new javax.swing.JMenuItem();
        eliminarPedido = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        pagarVentas = new javax.swing.JMenuItem();
        salir = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 297, Short.MAX_VALUE)
        );

        jMenuBar1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        InventarioMenu.setText("Inventario");

        agregarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-agregar-a-carrito-de-compras-16.png"))); // NOI18N
        agregarProducto.setText("Agregar producto(s)");
        agregarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarProductoActionPerformed(evt);
            }
        });
        InventarioMenu.add(agregarProducto);

        modificarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-actualizaciones-disponibles-16.png"))); // NOI18N
        modificarProducto.setText("Modificar Producto(s)");
        modificarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarProductoActionPerformed(evt);
            }
        });
        InventarioMenu.add(modificarProducto);

        eliminarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        eliminarProducto.setText("Eliminar Producto(s)");
        eliminarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarProductoActionPerformed(evt);
            }
        });
        InventarioMenu.add(eliminarProducto);

        jMenuBar1.add(InventarioMenu);

        jMenu2.setText("Cliente");

        agregarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-añadir-usuario-masculino-16.png"))); // NOI18N
        agregarCliente.setText("Agregar");
        agregarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarClienteActionPerformed(evt);
            }
        });
        jMenu2.add(agregarCliente);

        modificarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-editar-usuario-masculino-16.png"))); // NOI18N
        modificarCliente.setText("Modificar");
        modificarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarClienteActionPerformed(evt);
            }
        });
        jMenu2.add(modificarCliente);

        eliminarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-retire-hombre-usuario-16.png"))); // NOI18N
        eliminarCliente.setText("Eliminar");
        eliminarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarClienteActionPerformed(evt);
            }
        });
        jMenu2.add(eliminarCliente);

        jMenuBar1.add(jMenu2);

        Pedido.setText("Pedido");

        agregarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-agregar-regla-16.png"))); // NOI18N
        agregarPedido.setText("Agregar");
        agregarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarPedidoActionPerformed(evt);
            }
        });
        Pedido.add(agregarPedido);

        consultarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-búsqueda-16.png"))); // NOI18N
        consultarPedido.setText("Consultar");
        consultarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarPedidoActionPerformed(evt);
            }
        });
        Pedido.add(consultarPedido);

        modificarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-actualizaciones-disponibles-16.png"))); // NOI18N
        modificarPedido.setText("Modificar");
        modificarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarPedidoActionPerformed(evt);
            }
        });
        Pedido.add(modificarPedido);

        eliminarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        eliminarPedido.setText("Eliminar");
        eliminarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarPedidoActionPerformed(evt);
            }
        });
        Pedido.add(eliminarPedido);

        jMenuBar1.add(Pedido);

        jMenu1.setText("Ventas");

        pagarVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-lista-de-transacciones-16.png"))); // NOI18N
        pagarVentas.setText("Pagar");
        pagarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagarVentasActionPerformed(evt);
            }
        });
        jMenu1.add(pagarVentas);

        jMenuBar1.add(jMenu1);

        salir.setText("Salir");
        salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salirMouseClicked(evt);
            }
        });
        jMenuBar1.add(salir);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void agregarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarProductoActionPerformed
        // TODO add your handling code here:
        new PantallaInventario(this, true,1).setVisible(true);
    }//GEN-LAST:event_agregarProductoActionPerformed

    private void salirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salirMouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_salirMouseClicked

    private void agregarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarClienteActionPerformed
        // TODO add your handling code here:
        new PantallaCliente (this,true,1).setVisible(true);
    }//GEN-LAST:event_agregarClienteActionPerformed

    private void modificarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarClienteActionPerformed
        // TODO add your handling code here:
        new PantallaCliente (this,true,2).setVisible(true);
    }//GEN-LAST:event_modificarClienteActionPerformed

    private void modificarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarProductoActionPerformed
        // TODO add your handling code here:
        new PantallaInventario(this, true,2).setVisible(true);
    }//GEN-LAST:event_modificarProductoActionPerformed

    private void eliminarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarProductoActionPerformed
        // TODO add your handling code here:
        new PantallaInventario(this, true,3).setVisible(true);
    }//GEN-LAST:event_eliminarProductoActionPerformed

    private void agregarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarPedidoActionPerformed
        // TODO add your handling code here:
        new PantallaPedido (this,true).setVisible(true);
        
    }//GEN-LAST:event_agregarPedidoActionPerformed

    private void eliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarClienteActionPerformed
        // TODO add your handling code here:
        new PantallaCliente  (this,true,3).setVisible(true);
    }//GEN-LAST:event_eliminarClienteActionPerformed

    private void consultarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarPedidoActionPerformed
        new PantallaConsultaPedido(this,true,2).setVisible(true);
    }//GEN-LAST:event_consultarPedidoActionPerformed

    private void eliminarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarPedidoActionPerformed
        new PantallaConsultaPedido(this,true,4).setVisible(true);
    }//GEN-LAST:event_eliminarPedidoActionPerformed

    private void modificarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarPedidoActionPerformed
        new PantallaConsultaPedido(this,true,3).setVisible(true);
    }//GEN-LAST:event_modificarPedidoActionPerformed

    private void pagarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagarVentasActionPerformed
        new PantallaVentas(this, true).setVisible(true);
    }//GEN-LAST:event_pagarVentasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu InventarioMenu;
    private javax.swing.JMenu Pedido;
    private javax.swing.JMenuItem agregarCliente;
    private javax.swing.JMenuItem agregarPedido;
    private javax.swing.JMenuItem agregarProducto;
    private javax.swing.JMenuItem consultarPedido;
    private javax.swing.JMenuItem eliminarCliente;
    private javax.swing.JMenuItem eliminarPedido;
    private javax.swing.JMenuItem eliminarProducto;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem modificarCliente;
    private javax.swing.JMenuItem modificarPedido;
    private javax.swing.JMenuItem modificarProducto;
    private javax.swing.JMenuItem pagarVentas;
    private javax.swing.JMenu salir;
    // End of variables declaration//GEN-END:variables
}
