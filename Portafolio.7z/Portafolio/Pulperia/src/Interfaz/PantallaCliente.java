/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;
import Clases.Cliente;
import java.awt.HeadlessException;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Meibelyn
 */
public class PantallaCliente extends javax.swing.JDialog {
    
    private int indice;
    
    private VentanaPrincipal parent;

    private final String[] arrayColumnas = {"ID", "Nombre", "Apellido", "Telefono"};

    /**
     * Creates new form PantallaCliente
     * @param parent
     * @param modal
     * @param indice
     */
    public PantallaCliente(VentanaPrincipal parent, boolean modal, int indice) {
        super(parent, modal);
        initComponents();
        this.parent = parent;
        llenarTabla();
        noEditarTabla();
        setIconImage(new ImageIcon(getClass().getResource("/Recursos/icons8-usuario-masculino-en-círculo-32.png")).getImage());
        setTitle("Cliente");
        switch (indice) {
            case 1:
                  botonGuardar.setVisible(false);
                  botonEliminar.setVisible(false);
                  break;
              case 2:
                  botonAgregar.setVisible(false);
                  botonEliminar.setVisible(false);
                  ID.enable(false);
                  break;
              case 3:
                  botonGuardar.setVisible(false);
                  botonAgregar.setVisible(false);
                  break;
              default:
                  break;
          }
        
    }
     public void limpiar()
    {
        nombre.setText("");
        apellido.setText("");
        ID.setText("");
        telefono.setText("");
    }
      private void llenarTabla() {
        //Llena la tabla que muestra todas las película un día determinado
        DefaultTableModel table = new DefaultTableModel();
        table.setColumnIdentifiers(arrayColumnas);
        Object[] columna = new Object[tablaClientes.getColumnCount()];
        //Recorrer el contenido del ArrayList
        for (Cliente clientes : parent.principal.getClientes()) {
            //Añadir cada elemento del ArrayList en el TableModel
            columna[0] = clientes.getID();
            columna[1] = clientes.getNombre();
            columna[2] = clientes.getApellido();
            columna[3] = clientes.getTelefono();

            //Añadimos las columnas a la tabla
            table.addRow(columna);
        }
        tablaClientes.setModel(table);
    }

    private void noEditarTabla() {
        for (int i =0;i<tablaClientes.getColumnCount();i++){
            Class <?> col_class = tablaClientes.getColumnClass(i);
            tablaClientes.setDefaultEditor(col_class, null);
        }
    }
    
    private void seleccionar() {
        try {
            if (tablaClientes.getSelectedRowCount() > 1) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar solo un cliente a la vez");
            } else if (tablaClientes.getSelectedRowCount() == 1) {

                indice = tablaClientes.getSelectedRow();
                //Obtiene el valor de la fila seleccionada en la columna 0(es decir el ID del cliente) y 
                //lo agrega a la caja de texto respectiva
                ID.setText(tablaClientes.getValueAt(tablaClientes.getSelectedRow(), 0).toString());
                nombre.setText(tablaClientes.getValueAt(tablaClientes.getSelectedRow(), 1).toString());
                apellido.setText(tablaClientes.getValueAt(tablaClientes.getSelectedRow(), 2).toString());
                telefono.setText(tablaClientes.getValueAt(tablaClientes.getSelectedRow(), 3).toString());

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private boolean idDuplicado(int id){
        boolean existe=false;
        for(Cliente cliente: parent.principal.getClientes()){
            if(cliente.getID() == id){
                existe = true;
            }
        }
        return existe;
    }
    
    public boolean buscarCliente(int id) {
        boolean estado = false;
        
        if (parent.principal.getClientes().get(id).getPedido().size() > 0) {
            estado = true;
        }

        return estado;
    }
    
    public boolean validarTelefono(String telefono){
        Pattern patron = Pattern.compile("^(\\d{8})$");
        
        return patron.matcher(telefono).matches();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        apellido = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        telefono = new javax.swing.JTextField();
        botonAgregar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClientes = new javax.swing.JTable();
        botonGuardar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconImage(null);

        jLabel1.setText("ID");

        jLabel2.setText("Nombre");

        jLabel3.setText("Apellido");

        jLabel4.setText("Telefono");

        botonAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-añadir-usuario-masculino-16.png"))); // NOI18N
        botonAgregar.setText("Agregar");
        botonAgregar.setMaximumSize(new java.awt.Dimension(95, 25));
        botonAgregar.setMinimumSize(new java.awt.Dimension(95, 25));
        botonAgregar.setPreferredSize(new java.awt.Dimension(97, 25));
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-cerrar-ventana-16.png"))); // NOI18N
        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        tablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido", "Telefono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaClientes);

        botonGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-guardar-16.png"))); // NOI18N
        botonGuardar.setText("Guardar");
        botonGuardar.setMaximumSize(new java.awt.Dimension(95, 25));
        botonGuardar.setMinimumSize(new java.awt.Dimension(95, 25));
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/icons8-basura-16.png"))); // NOI18N
        botonEliminar.setLabel("Eliminar");
        botonEliminar.setMaximumSize(new java.awt.Dimension(95, 25));
        botonEliminar.setMinimumSize(new java.awt.Dimension(95, 25));
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(133, 133, 133)
                                .addComponent(jLabel2)
                                .addGap(105, 105, 105)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(apellido, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(botonCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(49, 49, 49))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(botonGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                                                .addComponent(botonAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                                            .addComponent(botonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(33, 33, 33))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(botonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonCancelar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        try {
            if (ID.getText().isEmpty() || nombre.getText().isEmpty() || apellido.getText().isEmpty() || telefono.getText().isEmpty()) {
                
                JOptionPane.showMessageDialog(null, "Hay espacios en sin completar");
                
            } else if(idDuplicado(Integer.parseInt(ID.getText())) == true){
                
                JOptionPane.showMessageDialog(null, "El ID ingresado ya existe");
                
            }else if(validarTelefono(telefono.getText()) == false){
                
                JOptionPane.showMessageDialog(null, "El número de teléfono no es válido");
                
            }else{
                Cliente cliente = new Cliente();
                cliente.setNombre(nombre.getText());
                cliente.setApellido(apellido.getText());
                cliente.setID(Integer.parseInt(ID.getText()));
                cliente.setTelefono(Integer.parseInt(telefono.getText()));

                parent.principal.agregar(cliente);

                JOptionPane.showMessageDialog(null, "¡Cliente agregado exitosamente!");
                llenarTabla();
                limpiar();

                //Guarda los datos en el txt
                parent.principal.guardarMemoria();
            }

        } catch (NumberFormatException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        try {
            if (nombre.getText().isEmpty() || apellido.getText().isEmpty() || ID.getText().isEmpty()||telefono.getText().isEmpty()){
                
                JOptionPane.showMessageDialog(null,"Hay espacios sin completar");
            
            }else if(validarTelefono(telefono.getText()) == false){
                
                JOptionPane.showMessageDialog(null, "El número de teléfono no es válido");
                
            }
            else {
                Cliente mCliente = new Cliente();

                mCliente.setNombre(nombre.getText());
                mCliente.setApellido(apellido.getText());
                mCliente.setID(Integer.parseInt(ID.getText()));
                mCliente.setTelefono(Integer.parseInt(telefono.getText()));

                parent.principal.modificar(mCliente, indice);
                JOptionPane.showMessageDialog(null,"¡Cliente modificado!");
                
                llenarTabla();
                limpiar();

                //Guarda los datos en el txt
                parent.principal.guardarMemoria();
                
            }
            
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        try {
            int id = tablaClientes.getSelectedRow();
            if (tablaClientes.getSelectedRowCount() == 1) {
                
                if (buscarCliente(id) == false) {
                    Cliente cliente = new Cliente();
                    
                    parent.principal.eliminar(cliente, tablaClientes.getSelectedRow());
                    
                    JOptionPane.showMessageDialog(null, "¡Cliente Eliminado!");

                    llenarTabla();

                    //Guarda los datos en el txt
                    parent.principal.guardarMemoria();
                } else {
                    JOptionPane.showMessageDialog(null, "El cliente tiene pedidos");
                }
            }else if(tablaClientes.getSelectedRowCount() < 1){
                 JOptionPane.showMessageDialog(null, "Seleccione el cliente a eliminar");
            }else if(tablaClientes.getSelectedRowCount() > 1){
                 JOptionPane.showMessageDialog(null, "Seleccione un cliente a la vez");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        
        this.setVisible(false);
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void tablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaClientesMouseClicked
        if(botonGuardar.isVisible()){
           seleccionar(); 
        }
    }//GEN-LAST:event_tablaClientesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PantallaCliente dialog = new PantallaCliente(new VentanaPrincipal(), true,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ID;
    private javax.swing.JTextField apellido;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nombre;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTextField telefono;
    // End of variables declaration//GEN-END:variables
}
