/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Laboratorio
 */
public class DataBase implements Serializable{
    private static final long serialVersionUID=2L;
    public List<Producto> inventario = new ArrayList();
    public List<Cliente> clientes = new ArrayList();
    public List<Pedido> pedidos = new ArrayList();
    public List<Venta> ventas = new ArrayList();
}
