/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.util.ArrayList;

public class Venta extends Pedido {
    private double total;

    public Venta() {
    }

    public Venta(int codigo, int estado) {
        super(codigo, estado);
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public ArrayList<Producto> getProducto() {
        return productos;
    }

    public void setProducto(ArrayList<Producto> producto) {
        this.productos = producto;
    }
    
    
}
