/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.util.ArrayList;

/**
 *
 * @author Steve
 */
public class Pedido extends Entidad{
    ArrayList <Producto> productos = new ArrayList();
    private int codigo;
    private int estado; 
    
    public Pedido() {  
    }
    
     public Pedido(int codigo, int estado) {
         this.codigo = codigo;
         this.estado = estado;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public  void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int isEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    } 
    
    public void agregarProducto(int codigo, int cantidad, String nombre, int precio){
        Producto producto = new Producto(codigo, cantidad, nombre, precio);
        productos.add(producto);
    }

    @Override
    public String toString() {
        return "Código Pedido=" + codigo +  "\n Estado=" + estado + "productos={" + productos + "}\n";
    }
    
    
   
}
