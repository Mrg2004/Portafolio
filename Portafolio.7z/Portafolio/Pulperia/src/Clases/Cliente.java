/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Meibelyn
 */
public class Cliente extends Entidad implements  Serializable  {
    
    private String nombre, apellido;
    private int ID, telefono;
    private  ArrayList <Pedido> pedidos = new ArrayList();

    public Cliente(String nombre, String apellido, int ID, int telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.ID = ID;
        this.telefono = telefono;
    }

    public Cliente() {
        
    }
    

    public ArrayList<Pedido> getPedido() {
        return pedidos;
    }

    public void setPedido(Pedido pedido) {
        pedidos.add(pedido);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", apellido=" + apellido + ", ID=" + ID + ", telefono=" + telefono + 
                "\n Pedidos=" + pedidos + '}';
    }
    
    
}
