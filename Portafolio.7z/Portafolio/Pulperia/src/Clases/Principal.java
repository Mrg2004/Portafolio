/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sarahi
 */
public  class Principal implements Serializable, Crudable {
    private ArrayList<Producto> inventario = new ArrayList();
    private ArrayList<Cliente> clientes = new ArrayList();
    private ArrayList<Pedido> pedidos = new ArrayList();
    private ArrayList<Venta> ventas = new ArrayList();

    private DataBase dataBase = new DataBase();

    public Principal() {
        
    }

    private void feedSerializableDataBase() throws Exception{
        try{
            dataBase.inventario.clear();
            for(Producto producto : this.inventario){
                dataBase.inventario.add(producto);
            }
            dataBase.clientes.clear();
            for(Cliente cliente : this.clientes){
                dataBase.clientes.add(cliente);
            }
            dataBase.pedidos.clear();
            for(Pedido pedido : this.pedidos){
                dataBase.pedidos.add(pedido);
            }
            dataBase.ventas.clear();
            for(Venta venta : this.ventas){
                dataBase.ventas.add(venta);
            }
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    private void consumeDatabase(DataBase dataBase) {
        if (dataBase.inventario.size() > 0) {
            for (Producto producto : dataBase.inventario) {
                this.inventario.add(producto);
            }
        }
        if (dataBase.clientes.size() > 0) {
            for (Cliente cliente : dataBase.clientes) {
                this.clientes.add(cliente);
            }
        }
        if (dataBase.pedidos.size() > 0) {
            for (Pedido pedido : dataBase.pedidos) {
                this.pedidos.add(pedido);
            }
        }
        if (dataBase.ventas.size() > 0) {
            for(Venta venta : dataBase.ventas){
                this.ventas.add(venta);
            }
        }
    }
    
    public void guardarMemoria()
    {
        //Almacena los datos del arreglo en un txt
        FileOutputStream out;
        ObjectOutputStream salida;
        try {
            
            out = new FileOutputStream("BaseDatos.txt");
            salida = new ObjectOutputStream (out);
            salida.writeObject(this.dataBase);
            out.close();  
        } 
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
    }
    
    public void leerMemoria()
    {
        //Lee los datos almacenados en el txt
        ObjectInputStream entrada;

        try (FileInputStream in = new FileInputStream("BaseDatos.txt")) {
            entrada = new ObjectInputStream(in);
            //Almaceno los datos del txt en al array de Tipos
            dataBase = (DataBase) entrada.readObject();
            this.consumeDatabase(dataBase);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public  List<Producto> getInventario() {
        return inventario;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public void setInventario(ArrayList<Producto> inventario) {
        this.inventario = inventario;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(ArrayList<Venta> ventas) {
        this.ventas = ventas;
    }

    
    @Override
    public void agregar(Entidad entidad) {
        if(entidad instanceof Cliente){
            this.clientes.add((Cliente)entidad);
        }else if(entidad instanceof Producto){
            this.inventario.add((Producto) entidad);
        } else if (entidad instanceof Pedido && !(entidad instanceof Venta)) {
            this.pedidos.add((Pedido) entidad);
        } else if (entidad instanceof Pedido && entidad instanceof Venta) {
            this.ventas.add((Venta) entidad);
        }
        try {
            this.feedSerializableDataBase();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    @Override
    public void modificar(Entidad entidad, int id) {
        if(entidad instanceof Cliente){
            this.clientes.set(id,(Cliente) entidad);
        }else if (entidad instanceof Producto) {
            this.inventario.set(id,(Producto) entidad);
        }

        try {
            this.feedSerializableDataBase();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
         
    }

    @Override
    public void eliminar(Entidad entidad, int id) {
        if(entidad instanceof Cliente){
            this.clientes.remove(id);
        } else if (entidad instanceof Producto) {
            this.inventario.remove(id);
        } else if (entidad instanceof Pedido && !(entidad instanceof Venta)) {
            this.pedidos.remove(id);
        }else if (entidad instanceof Pedido && entidad instanceof Venta){
            this.ventas.remove(id);
        }
        try {
            this.feedSerializableDataBase();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
}
