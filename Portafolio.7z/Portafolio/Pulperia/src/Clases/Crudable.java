/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public interface Crudable  {
    public abstract void agregar(Entidad entidad);
    public abstract void eliminar(Entidad entidad, int id);
    public abstract void modificar(Entidad entidad, int id);
    
}
