/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Sarahi
 */
public class Producto extends Entidad{
    private int codigoProducto, cantidad;
    private String nombreProducto;
    private double precio;

    public Producto() {
    }

    public Producto(int codigoProducto, int cantidad, String nombreProducto, double precio) {
        this.codigoProducto = codigoProducto;
        this.cantidad = cantidad;
        this.nombreProducto = nombreProducto;
        this.precio = precio;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public int getCantidadDisponible() {
        return cantidad;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidad = cantidadDisponible;
    }

    public void setNombreProducto(String nombreProducto) {
        if (nombreProducto == null || nombreProducto.isEmpty()) {
            throw new RuntimeException("No se aceptan valores vacíos o nulos");

        } else {
            this.nombreProducto = nombreProducto;
        }
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Información Producto{" + "codigoProducto=" + codigoProducto + ", cantidad=" + cantidad + ", nombreProducto=" + nombreProducto + ", precio=" + precio + '}';
    }
    
    
}
