/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sarahi
 */
public class PrincipalTest {
    
    public PrincipalTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of guardarMemoria method, of class Principal.
     */
    @Test
    public void testGuardarMemoria() {
        System.out.println("guardarMemoria");
        Principal instance = new Principal();
        instance.guardarMemoria();
    }

    /**
     * Test of leerMemoria method, of class Principal.
     */
    @Test
    public void testLeerMemoria() {
        System.out.println("leerMemoria");
        Principal instance = new Principal();
        instance.leerMemoria();
    }

    /**
     * Test of setClientes method, of class Principal.
     */
    @Test
    public void testSetClientes() {
        System.out.println("setClientes");
        ArrayList<Cliente> clientes = null;
        Principal instance = new Principal();
        instance.setClientes(clientes);
    }

    /**
     * Test of setPedidos method, of class Principal.
     */
    @Test
    public void testSetPedidos() {
        System.out.println("setPedidos");
        ArrayList<Pedido> pedidos = null;
        Principal instance = new Principal();
        instance.setPedidos(pedidos);
    }


    /**
     * Test of setVentas method, of class Principal.
     */
    @Test
    public void testSetVentas() {
        System.out.println("setVentas");
        ArrayList<Venta> ventas = null;
        Principal instance = new Principal();
        instance.setVentas(ventas);
    }

    /**
     * Test of agregar method, of class Principal.
     */
    @Test
    public void testAgregar() {
        System.out.println("agregar");
        Entidad entidad = null;
        Principal instance = new Principal();
        instance.agregar(entidad);
    }

    /**
     * Test of modificar method, of class Principal.
     */
    @Test
    public void testModificar() {
        System.out.println("modificar");
        Entidad entidad = null;
        int id = 0;
        Principal instance = new Principal();
        instance.modificar(entidad, id);
    }

    /**
     * Test of eliminar method, of class Principal.
     */
    @Test
    public void testEliminar() {
        System.out.println("eliminar");
        Entidad entidad = null;
        int id = 0;
        Principal instance = new Principal();
        instance.eliminar(entidad, id);
    }
    
}
