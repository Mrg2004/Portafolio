/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sarahi
 */
public class ProductoTest {
    
    public ProductoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getCodigoProducto method, of class Producto.
     */
    @Test
    public void testGetCodigoProducto() {
        System.out.println("getCodigoProducto");
        Producto instance = new Producto();
        int expResult = 0;
        int result = instance.getCodigoProducto();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCantidadDisponible method, of class Producto.
     */
    @Test
    public void testGetCantidadDisponible() {
        System.out.println("getCantidadDisponible");
        Producto instance = new Producto();
        int expResult = 0;
        int result = instance.getCantidadDisponible();
        assertEquals(expResult, result);;
    }

    /**
     * Test of getNombreProducto method, of class Producto.
     */
    @Test
    public void testGetNombreProducto() {
        System.out.println("getNombreProducto");
        Producto instance = new Producto();
        String expResult = null;
        String result = instance.getNombreProducto();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPrecio method, of class Producto.
     */
    @Test
    public void testGetPrecio() {
        System.out.println("getPrecio");
        Producto instance = new Producto();
        double expResult = 0.0;
        double result = instance.getPrecio();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of setCodigoProducto method, of class Producto.
     */
    @Test
    public void testSetCodigoProducto() {
        System.out.println("setCodigoProducto");
        int codigoProducto = 0;
        Producto instance = new Producto();
        instance.setCodigoProducto(codigoProducto);
    }

    /**
     * Test of setCantidadDisponible method, of class Producto.
     */
    @Test
    public void testSetCantidadDisponible() {
        System.out.println("setCantidadDisponible");
        int cantidadDisponible = 0;
        Producto instance = new Producto();
        instance.setCantidadDisponible(cantidadDisponible);
    }

    /**
     * Test of setNombreProducto method, of class Producto.
     */
    @Test
    public void testSetNombreProducto() {
        System.out.println("setNombreProducto");
        String nombreProducto = "Arroz";
        Producto instance = new Producto();
        instance.setNombreProducto(nombreProducto);
    }

    /**
     * Test of setPrecio method, of class Producto.
     */
    @Test
    public void testSetPrecio() {
        System.out.println("setPrecio");
        double precio = 0.0;
        Producto instance = new Producto();
        instance.setPrecio(precio);
    }

    /**
     * Test of toString method, of class Producto.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Producto instance = new Producto();
        String expResult = "Información Producto{" + "codigoProducto=" + 0 + ", cantidad=" + 0+ ", nombreProducto=" + null + ", precio=" + 0.0 + '}';
        String result = instance.toString();
        assertEquals(expResult, result);
    }
    
}
