/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sarahi
 */
public class VentaTest {
    
    public VentaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getTotal method, of class Venta.
     */
    @Test
    public void testGetTotal() {
        System.out.println("getTotal");
        Venta instance = new Venta();
        double expResult = 0.0;
        double result = instance.getTotal();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of setTotal method, of class Venta.
     */
    @Test
    public void testSetTotal() {
        System.out.println("setTotal");
        double total = 0.0;
        Venta instance = new Venta();
        instance.setTotal(total);
    }


    /**
     * Test of setProducto method, of class Venta.
     */
    @Test
    public void testSetProducto() {
        System.out.println("setProducto");
        ArrayList<Producto> producto = null;
        Venta instance = new Venta();
        instance.setProducto(producto);
    }
    
}
