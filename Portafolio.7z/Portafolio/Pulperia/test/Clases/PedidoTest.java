/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sarahi
 */
public class PedidoTest {
    
    public PedidoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setProductos method, of class Pedido.
     */
    @Test
    public void testSetProductos() {
        System.out.println("setProductos");
        ArrayList<Producto> productos = null;
        Pedido instance = new Pedido();
        instance.setProductos(productos);
    }

    /**
     * Test of getCodigo method, of class Pedido.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        Pedido instance = new Pedido();
        int expResult = 0;
        int result = instance.getCodigo();
        assertEquals(expResult, result);
    }

    /**
     * Test of setCodigo method, of class Pedido.
     */
    @Test
    public void testSetCodigo() {
        System.out.println("setCodigo");
        int codigo = 0;
        Pedido instance = new Pedido();
        instance.setCodigo(codigo);
    }

    /**
     * Test of isEstado method, of class Pedido.
     */
    @Test
    public void testIsEstado() {
        System.out.println("isEstado");
        Pedido instance = new Pedido();
        int expResult = 0;
        int result = instance.isEstado();
        assertEquals(expResult, result);
    }

    /**
     * Test of setEstado method, of class Pedido.
     */
    @Test
    public void testSetEstado() {
        System.out.println("setEstado");
        int estado = 0;
        Pedido instance = new Pedido();
        instance.setEstado(estado);
    }

    /**
     * Test of agregarProducto method, of class Pedido.
     */
    @Test
    public void testAgregarProducto() {
        System.out.println("agregarProducto");
        int codigo = 0;
        int cantidad = 0;
        String nombre = "";
        int precio = 0;
        Pedido instance = new Pedido();
        instance.agregarProducto(codigo, cantidad, nombre, precio);
    }

    
}
