/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerparcialterceraparteprimerejercicio;
import Entidad.Computador;

/**
 *
 * @author Meibelyn
 */
public class PrimerParcialTerceraPartePrimerEjercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Computador dell = new Computador();
        dell.setProcesador("Intel CORE i5");
        dell.setDiscoDuro("320GB, SATA");
        dell.setMemoriaRam("8 GB, DDR3");
        dell.setSistemaOperativo("Windows 10");
        dell.setTarjetaMadre("Intel");

    }

}
