/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1proyecto;
import ejercicio1proyecto.Persona;
import javax.swing.JOptionPane;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio1Proyecto extends Persona{

    /**
     * @param args the command line arguments
     */
    //Se crea una lista para almacenar las persona
    public static void main(String[] args) {
       Persona miPersona = new Persona();
       //Se le agregan los atributos a la persona
     miPersona.setNombre("Juan");
     miPersona.setApellido("Jimenez");
     miPersona.setEdad(20);
     miPersona.setSexo("masculino");
        System.out.println(miPersona);
        
    }
    
}
