/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5proyecto;

/**
 *
 * @author Meibelyn
 */
public class Calculadora {
    //Se indic< como se deben de realizar las operaciones
        public int suma(int operando1, int operando2) {
        return operando1 + operando2;
    }

    public int resta(int operando1, int operando2) {
        return operando1 - operando2;

    }

    public int multiplicacion(int operando1, int operando2) {
        return operando1 * operando2;

    }

    public double divi(int operando1, int operando2) {
        return operando1 + operando2;

    }
}
