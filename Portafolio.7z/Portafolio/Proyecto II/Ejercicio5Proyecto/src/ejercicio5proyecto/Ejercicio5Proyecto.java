/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5proyecto;

import java.util.Scanner;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio5Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Calculadora calculadora = new Calculadora();

        boolean seguir = true, resultadoEsDecimal = true;
        Scanner entrada = new Scanner(System.in);
//Se declaran las variables para la calculadora
        double operando1;
        double operando2;
        //Se inicializa la variable que va a dar el resultado
        double resultadoDecimal = 0;
        String operador;
        int contador = 0;

        System.out.println("Digite el numero inicial");
        operando1 = (double) (entrada.nextInt());
//Menu para seguir realizando las operaciones como el usuario lo desee
        while (seguir == true) {

            if (contador > 0) {
                operando1 = resultadoDecimal;
            }

            System.out.println("Digite el operador ");
            operador = entrada.next();

            System.out.println("Digite el siguiente numero");
            operando2 = (double) (entrada.nextInt());

            switch (operador) {
                case "+":
                    resultadoDecimal = operando1 + operando2;

                    break;
                case "-":
                    resultadoDecimal = operando1 - operando2;

                    break;
                case "/":
                    resultadoDecimal = operando1 / operando2;

                    break;
                case "*":
                    resultadoDecimal = operando1 * operando2;

                    break;
            }

            System.out.println("Desea realizar otra operación ? ");
            String decision = (entrada.next()).toLowerCase();

            if (decision.equals("si")) {
                seguir = true;

            } else {
                seguir = false;

            }
            contador = contador + 1;
        }

        System.out.println("El resultado es : " + resultadoDecimal);

    }
}

