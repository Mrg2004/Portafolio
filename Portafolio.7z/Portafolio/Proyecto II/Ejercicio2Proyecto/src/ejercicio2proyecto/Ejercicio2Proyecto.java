/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2proyecto;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Meibelyn
 */
public class Ejercicio2Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Se hace la lista de personas para guardar las personas
         List<Persona> personas = 
                new ArrayList<Persona>();
        Persona fulanito = new Estudiante();
        fulanito.setNombre("Carlitos");
        ((Estudiante)fulanito).setNota(100);
        //Se le agregan los atributos a los estudiantes y profesores
        Persona sutanito = new Profesor("Roberto");
        ((Profesor)sutanito).setHorario("Diurno");
        Estudiante menganito = new Estudiante("John");
        personas.add(fulanito);
        personas.add(sutanito);
        personas.add(menganito);
        try{
            printPersonas(personas);
        }catch(Exception ex){
            System.out.println(
                ex.getMessage());
        }
    }

    public static void printPersonas(
            List<Persona> personas) 
                throws Exception {
        for(Persona persona : personas){
            System.out.println(
                    persona.getNombre());
         
    }
    }
    
}
