/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4proyecto;

import Entidades.BaseDatos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Laboratorio
 */
public class Modificar extends javax.swing.JDialog {

    private Principal parent;
    private int op;
    Connection con = null;
    BaseDatos conect = new BaseDatos();
    private final String[] columnasC = {"Id", "Nombre", "Apellido"};
    private final String[] columnasE = {"Id", "Nombre", "Contraseña", "Tipo"};
    private final String[] columnasP = {"Id", "Nombre", "Director", "Duracion"};
    private final String[] columnasS = {"Id", "Nombre", "Director", "Capitulos"};
    private final String[] columnasD = {"Id", "Nombre", "Director", "Duracion"};

    public Modificar(Principal parent, boolean modal, int op) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        this.parent = parent;
        this.op = op;
        con = conect.getConnection();
        llenarTablaCliente();
        this.setLocationRelativeTo(null);
        if (op == 1) {
            llenarTablaCliente();
        } else if (op == 2) {
            llenarTablaEmpleado();
        } else if (op == 3) {
            llenarTablaPelicula();

        } else if (op == 4) {
            llenarTablaSerie();
        }
        else if (op==5){
            llenarTablaDocumental();
        }
    }

    public void llenarTablaCliente() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasC);
        Object[] columna = new Object[columnasC.length];
        String datos = "select Id,nombre,apellido from Clientes";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("apellido");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }

    public void llenarTablaEmpleado() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasE);
        Object[] columna = new Object[columnasE.length];
        String datos = "select Id,nombre,contrasena,tipo from Empleados";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("contrasena");
                columna[2] = resultado.getInt("contrasena");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }

    public void llenarTablaPelicula() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasP);
        Object[] columna = new Object[columnasP.length];
        String datos = "select Id,nombre,director,duracion from Peliculas";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("duracion");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);
    }
    public void llenarTablaSerie() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasS);
        Object[] columna = new Object[columnasS.length];
        String datos = "select Id,nombre,director,capitulos from Series";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("capitulos");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);
    }
       public void llenarTablaDocumental() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasD);
        Object[] columna = new Object[columnasD.length];
        String datos = "select Id,nombre,director,duracion from Documentales";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("duracion");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
            
        }
        tabla.setModel(tabla1);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        botonModi = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        botonModi.setText("Modificar");
        botonModi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addComponent(botonModi))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(botonModi)
                .addGap(47, 47, 47))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonModiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModiActionPerformed
        try {
            if (op == 1) {
                if (tabla.getSelectedRowCount() == 1) {
                    String datos = "update Clientes set nombre=?,apellido=? where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
                    PreparedStatement ps = con.prepareStatement(datos);
                    ps.setString(1, tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                    ps.setString(2, tabla.getValueAt(tabla.getSelectedRow(), 2).toString());

                    ps.executeUpdate();

                    tabla.clearSelection();
                    llenarTablaCliente();
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente");

                    ps.close();
                }
            } else if (op == 2) {
                if (tabla.getSelectedRowCount() == 1) {
                    String datos = "update Empleados set nombre=?,contrasena=?,tipo=? where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
                    PreparedStatement ps = con.prepareStatement(datos);
                    ps.setString(1, tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                    ps.setString(2, tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                    ps.setInt(3, Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 3).toString()));
                    ps.executeUpdate();

                    tabla.clearSelection();
                    llenarTablaEmpleado();
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente");

                    ps.close();
                }
            } else if (op == 3) {
                if (tabla.getSelectedRowCount() == 1) {
                    String datos = "update Peliculas set nombre=?,director=?,duracion=? where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
                    PreparedStatement ps = con.prepareStatement(datos);
                    ps.setString(1, tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                    ps.setString(2, tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                    ps.setInt(3, Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 3).toString()));
                    ps.executeUpdate();

                    tabla.clearSelection();
                    llenarTablaPelicula();
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente");

                    ps.close();
                }
            }else if (op == 4) {
                if (tabla.getSelectedRowCount() == 1) {
                    String datos = "update Series set nombre=?,director=?,capitulos=? where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
                    PreparedStatement ps = con.prepareStatement(datos);
                    ps.setString(1, tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                    ps.setString(2, tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                    ps.setInt(3, Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 3).toString()));
                    ps.executeUpdate();

                    tabla.clearSelection();
                    llenarTablaSerie();
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente");

                    ps.close();
                }
            }
            else if (op == 5) {
                if (tabla.getSelectedRowCount() == 1) {
                    String datos = "update Documentales set nombre=?,director=?,duracion=? where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
                    PreparedStatement ps = con.prepareStatement(datos);
                    ps.setString(1, tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                    ps.setString(2, tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                    ps.setInt(3, Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 3).toString()));
                    ps.executeUpdate();

                    tabla.clearSelection();
                    llenarTablaDocumental();
                    JOptionPane.showMessageDialog(null, "Modificado exitosamente");

                    ps.close();
                }
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
    }//GEN-LAST:event_botonModiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Modificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Modificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Modificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Modificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Modificar dialog = new Modificar(new Principal(0), true,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonModi;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
