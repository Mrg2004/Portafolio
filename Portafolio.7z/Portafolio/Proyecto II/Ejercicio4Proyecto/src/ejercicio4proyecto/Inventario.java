/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4proyecto;

import Entidades.BaseDatos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Meibelyn
 */
public class Inventario extends javax.swing.JDialog {

    /**
     * Creates new form Pelicula
     */
    private Principal parent;
    private int op;
    Connection con = null;
    BaseDatos conect = new BaseDatos();
    private final String[] columnasP = {"Id", "Nombre", "Director", "Duracion"};
    private final String[] columnasS = {"Id", "Nombre", "Director", "Capitulos"};
    private final String[] columnasD = {"Id", "Nombre", "Director", "Duracion"};
    
    public Inventario(Principal parent, boolean modal, int op) {
        super(parent, modal);
        initComponents();
        con = conect.getConnection();
        this.setLocationRelativeTo(null);
        this.parent = parent;
        this.op = op;
        if (op == 1) {
            capitulos.setVisible(false);
            labelCant.setVisible(false);
            llenarTablaPelicula();
            noEditarTabla();
            eliminar.setVisible(false);
        } else if (op == 2) {
            capitulos.setVisible(true);
            labelCant.setVisible(true);
            labelDura.setVisible(false);
            duracion.setVisible(false);
            eliminar.setVisible(false);
            llenarTablaSerie();
            noEditarTabla();
        }
        else if (op == 3) {
            capitulos.setVisible(false);
            labelCant.setVisible(false);
            llenarTablaDocumental();
            noEditarTabla();
            eliminar.setVisible(false);
        }
    
        else if(op==5){
            agregar.setVisible(false);
            ocultar(false);
            llenarTablaPelicula();
        }
         else if(op==6){
            agregar.setVisible(false);
            ocultar(false);
            llenarTablaSerie();
        }
          else if(op==7){
            agregar.setVisible(false);
            ocultar(false);
            llenarTablaDocumental();
        }
        
    }
    
    public void llenarTablaPelicula() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasP);
        Object[] columna = new Object[columnasP.length];
        String datos = "select Id,nombre,director,duracion from Peliculas";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("duracion");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
            
        }
        tabla.setModel(tabla1);
    }

    public void llenarTablaSerie() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasS);
        Object[] columna = new Object[columnasS.length];
        String datos = "select Id,nombre,director,capitulos from Series";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("capitulos");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
            
        }
        tabla.setModel(tabla1);
        
    }
    public void llenarTablaDocumental() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasD);
        Object[] columna = new Object[columnasD.length];
        String datos = "select Id,nombre,director,duracion from Documentales";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getInt("duracion");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
            
        }
        tabla.setModel(tabla1);
    }

    public boolean validarPelicula(String nombrePelicula) {
        boolean existe = false;
        String info = "select nombre from Peliculas";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(info);
            while (resultado.next()) {
                if (resultado.getString("nombre").equals(nombre)) {
                    existe = true;
                    break;
                }
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
        return existe;
    }

    public boolean validarSerie(String nombreSerie) {
        boolean existe = false;
        String info = "select nombre from Series";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(info);
            while (resultado.next()) {
                if (resultado.getString("nombre").equals(nombre)) {
                    existe = true;
                    break;
                }
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
        return existe;
    }
    public boolean validarDocumental(String nombreDocumental) {
        boolean existe = false;
        String info = "select nombre from Documentales";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(info);
            while (resultado.next()) {
                if (resultado.getString("nombre").equals(nombre)) {
                    existe = true;
                    break;
                }
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
        return existe;
    }

    private void noEditarTabla() {
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            Class<?> col_class = tabla.getColumnClass(i);
            tabla.setDefaultEditor(col_class, null);            
        }
    }
        private boolean ocultar(boolean limpiar){
            labelNombre.setVisible(limpiar);
            nombre.setVisible(limpiar);
            labelDirector.setVisible(limpiar);
            director.setVisible(limpiar);
            labelDura.setVisible(limpiar);
            duracion.setVisible(limpiar);
            labelCant.setVisible(limpiar);
            capitulos.setVisible(limpiar);
            return limpiar;
        }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelNombre = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        labelDirector = new javax.swing.JLabel();
        director = new javax.swing.JTextField();
        labelDura = new javax.swing.JLabel();
        duracion = new javax.swing.JTextField();
        agregar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        labelCant = new javax.swing.JLabel();
        capitulos = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        labelNombre.setText("Nombre");

        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        labelDirector.setText("Director");

        labelDura.setText("Duracion(min)");

        agregar.setText("Agregar");
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });

        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        labelCant.setText("Cantidad Capitulos");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(capitulos, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                        .addGap(274, 274, 274)
                        .addComponent(agregar)
                        .addGap(18, 18, 18)
                        .addComponent(eliminar)
                        .addGap(172, 172, 172))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(labelNombre)
                                .addComponent(labelDirector)
                                .addComponent(director)
                                .addComponent(nombre, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                                .addComponent(labelDura)
                                .addComponent(duracion))
                            .addComponent(labelCant))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelNombre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labelDirector)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(director, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(labelDura)
                        .addGap(13, 13, 13)
                        .addComponent(duracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(labelCant)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(capitulos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(eliminar)
                            .addComponent(agregar))
                        .addGap(0, 21, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreActionPerformed

    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
        try {
            if (op==1){
                if (validarPelicula(nombre.getText())) {
                    JOptionPane.showMessageDialog(null, "La pelicula ya esta registrada");
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                } else   {
                    noEditarTabla();
                    PreparedStatement ps = con.prepareStatement("insert into Peliculas(nombre,director,duracion)values(?,?,?)");
                    ps.setString(1, nombre.getText());
                    ps.setString(2, director.getText());
                    ps.setString(3, duracion.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Pelicula agregada satisfactoriamente");
                    llenarTablaPelicula();
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                }
            }
            
            else if (op==2){
                if (validarSerie(nombre.getText())) {
                    JOptionPane.showMessageDialog(null, "La serie ya esta registrada");
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                    capitulos.setText(null);
                } else {
                    PreparedStatement ps = con.prepareStatement("insert into Series(nombre,director,capitulos)values(?,?,?)");
                    ps.setString(1, nombre.getText());
                    ps.setString(2, director.getText());
                     ps.setString(3, capitulos.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Serie agregada satisfactoriamente");
                    llenarTablaSerie();
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                    capitulos.setText(null);
                }
                
            }
            if (op==3){
                if (validarDocumental(nombre.getText())) {
                    JOptionPane.showMessageDialog(null, "El documental ya esta registrado");
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                } else   {
                    noEditarTabla();
                    PreparedStatement ps = con.prepareStatement("insert into Documentales(nombre,director,duracion)values(?,?,?)");
                    ps.setString(1, nombre.getText());
                    ps.setString(2, director.getText());
                    ps.setString(3, duracion.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Documental agregado satisfactoriamente");
                    llenarTablaDocumental();
                    nombre.setText(null);
                    director.setText(null);
                    duracion.setText(null);
                }
            }
            
         }catch (SQLException ex){
           JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);  
        }
    }//GEN-LAST:event_agregarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
       try{
       if (op==5){
            String eliminarP = "delete from Peliculas where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
              PreparedStatement ps = con.prepareStatement(eliminarP);
              ps.execute();
              JOptionPane.showMessageDialog(null, "Pelicula eliminada exitosamente");
              llenarTablaPelicula();
       }
       else if (op==6){
            String eliminarS = "delete from Series where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
              PreparedStatement ps = con.prepareStatement(eliminarS);
              ps.execute();
              JOptionPane.showMessageDialog(null, "Serie eliminada exitosamente");
              llenarTablaSerie();
       }
       else if (op==7){
            String eliminarD = "delete from Documentales where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
              PreparedStatement ps = con.prepareStatement(eliminarD);
              ps.execute();
              JOptionPane.showMessageDialog(null, "Documental eliminado exitosamente");
              llenarTablaDocumental();
       }
       }catch (SQLException ex){
           JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);  
        }
    }//GEN-LAST:event_eliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 Inventario dialog = new Inventario(new Principal(0), true,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agregar;
    private javax.swing.JTextField capitulos;
    private javax.swing.JTextField director;
    private javax.swing.JTextField duracion;
    private javax.swing.JButton eliminar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCant;
    private javax.swing.JLabel labelDirector;
    private javax.swing.JLabel labelDura;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JTextField nombre;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
