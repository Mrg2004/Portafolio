/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4proyecto;

import Entidades.BaseDatos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Meibelyn
 */
public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    Connection con = null;
    BaseDatos conect = new BaseDatos();
    private final String[] columnasC= {"Id","Nombre", "Apellido"};
    private final String[] columnasE= {"Id","Nombre", "Contraseña","Tipo"};
    private int op2,op3;

    public Principal(int tipo) {
        con = conect.getConnection();
        initComponents();
        this.setLocationRelativeTo(null);  
        ocultar(false);
        botonEliminar.setVisible(false);
        

    }

    public void llenarTablaCliente() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasC);
        Object[] columna = new Object[columnasC.length];
        String datos = "select Id,nombre,apellido from Clientes";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("apellido");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }
    public boolean validarCliente(String nombreCliente,String apellidoCliente){
        boolean existe=false;
        String info = "select nombre,apellido from Clientes";
        try{
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(info);
            while (resultado.next()) {
                if (resultado.getString("nombre").equals(nombreCliente)&&resultado.getString("apellido").equals(apellidoCliente)) {
                    existe = true;
                    break;
                }
            }
        }catch (SQLException ex){
           JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);  
        }
        
        return existe;
    }
     private void noEditarTabla(){
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            Class <?> col_class = tabla.getColumnClass(i);
            tabla.setDefaultEditor(col_class, null); 
        }
    }
     public void ocultar(boolean limpiar) {
         labelNombre.setVisible(limpiar);
         nombreCliente.setVisible(limpiar);
         labelApellido.setVisible(limpiar);
         botonAgregar.setVisible(limpiar);
         datosNombre.setVisible(limpiar);
         datosId.setVisible(limpiar);
         botonBuscar.setVisible(limpiar);
         datosNombre.setVisible(limpiar);
         datosId.setVisible(limpiar);
         botonBuscar.setVisible(limpiar);
         modoBus.setVisible(limpiar);

    }
     public void llenarTablaEmpleado() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasE);
        Object[] columna = new Object[columnasE.length];
        String datos = "select Id,nombre,contrasena,tipo from Empleados";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("contrasena");
                columna[2] = resultado.getInt("tipo");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }
     public void llenarTablaSelecCli(String nombreSelec){
         DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasC);
        Object[] columna = new Object[columnasC.length];
        String datos = "select Id,nombre,apellido from Clientes where nombre = '" + nombreSelec +"'";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("apellido");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }

    public void llenarTablaSelecCliI(String id) {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasC);
        Object[] columna = new Object[columnasC.length];
        String datos = "select Id,nombre,apellido from Clientes where nombre = '" + id + "'";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("apellido");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);

        }
        tabla.setModel(tabla1);

    }
    public void llenarComboCli(){
        try {
            datosId.setVisible(true);
            botonBuscar.setVisible(true);
            datosNombre.setVisible(false);
            String datos = "select  Id  from Clientes";
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            datosId.removeAllItems();
            while (resultado.next()) {
                datosId.addItem(resultado.getString("id"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
    }
      public void llenarComboCliN(){
        try {
            datosNombre.setVisible(true);
            botonBuscar.setVisible(true);
            datosId.setVisible(false);
            String datos = "select  nombre from Clientes";
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            datosNombre.removeAllItems();
            while (resultado.next()) {
                datosNombre.addItem(resultado.getString("nombre"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        labelNombre = new javax.swing.JLabel();
        nombreCliente = new javax.swing.JTextField();
        labelApellido = new javax.swing.JLabel();
        apellidoCliente = new javax.swing.JTextField();
        botonAgregar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();
        datosNombre = new javax.swing.JComboBox<>();
        datosId = new javax.swing.JComboBox<>();
        botonBuscar = new javax.swing.JButton();
        modoBus = new javax.swing.JComboBox<>();
        comboCliente = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuCliente = new javax.swing.JMenu();
        agregarCliente = new javax.swing.JMenuItem();
        modificarCliente = new javax.swing.JMenuItem();
        eliminarCliente = new javax.swing.JMenuItem();
        menuEmpleado = new javax.swing.JMenu();
        consultarEmpleado = new javax.swing.JMenuItem();
        modificarEmpleado = new javax.swing.JMenuItem();
        eliminarEmpleado = new javax.swing.JMenuItem();
        menuInventario = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        agregarPelicula = new javax.swing.JMenuItem();
        modificarPelicula = new javax.swing.JMenuItem();
        eliminarPelicula = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        agregarSerie = new javax.swing.JMenuItem();
        modificarSerie = new javax.swing.JMenuItem();
        eliminarSerie = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        agregarDoc = new javax.swing.JMenuItem();
        modDoc = new javax.swing.JMenuItem();
        eliminarDoc = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        agregarAlquiler = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        labelNombre.setText("Nombre");

        labelApellido.setText("Apellido");

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        datosNombre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un nombre" }));
        datosNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                datosNombreActionPerformed(evt);
            }
        });

        datosId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un ID" }));
        datosId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                datosIdActionPerformed(evt);
            }
        });

        botonBuscar.setText("Buscar");
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });

        modoBus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione el modo de busqueda", "ID", "Nombre" }));
        modoBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modoBusActionPerformed(evt);
            }
        });

        comboCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un cliente" }));

        menuCliente.setText("Cliente");

        agregarCliente.setText("Agregar");
        agregarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarClienteActionPerformed(evt);
            }
        });
        menuCliente.add(agregarCliente);

        modificarCliente.setText("Modificar");
        modificarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarClienteActionPerformed(evt);
            }
        });
        menuCliente.add(modificarCliente);

        eliminarCliente.setText("Eliminar");
        eliminarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarClienteActionPerformed(evt);
            }
        });
        menuCliente.add(eliminarCliente);

        jMenuBar1.add(menuCliente);

        menuEmpleado.setText("Empleado");

        consultarEmpleado.setText("Consultar");
        consultarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarEmpleadoActionPerformed(evt);
            }
        });
        menuEmpleado.add(consultarEmpleado);

        modificarEmpleado.setText("Modificar");
        modificarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarEmpleadoActionPerformed(evt);
            }
        });
        menuEmpleado.add(modificarEmpleado);

        eliminarEmpleado.setText("Eliminar");
        eliminarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarEmpleadoActionPerformed(evt);
            }
        });
        menuEmpleado.add(eliminarEmpleado);

        jMenuBar1.add(menuEmpleado);

        menuInventario.setText("Inventario");

        jMenu1.setText("Pelicula");

        agregarPelicula.setText("Agregar");
        agregarPelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarPeliculaActionPerformed(evt);
            }
        });
        jMenu1.add(agregarPelicula);

        modificarPelicula.setText("Modificar");
        modificarPelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarPeliculaActionPerformed(evt);
            }
        });
        jMenu1.add(modificarPelicula);

        eliminarPelicula.setText("Eliminar");
        eliminarPelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarPeliculaActionPerformed(evt);
            }
        });
        jMenu1.add(eliminarPelicula);

        menuInventario.add(jMenu1);

        jMenu3.setText("Serie");

        agregarSerie.setText("Agregar");
        agregarSerie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarSerieActionPerformed(evt);
            }
        });
        jMenu3.add(agregarSerie);

        modificarSerie.setText("Modificar");
        modificarSerie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarSerieActionPerformed(evt);
            }
        });
        jMenu3.add(modificarSerie);

        eliminarSerie.setText("Eliminar");
        eliminarSerie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarSerieActionPerformed(evt);
            }
        });
        jMenu3.add(eliminarSerie);

        menuInventario.add(jMenu3);

        jMenu4.setText("Documental");

        agregarDoc.setText("Agregar");
        agregarDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarDocActionPerformed(evt);
            }
        });
        jMenu4.add(agregarDoc);

        modDoc.setText("Modificar");
        modDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modDocActionPerformed(evt);
            }
        });
        jMenu4.add(modDoc);

        eliminarDoc.setText("Eliminar");
        eliminarDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarDocActionPerformed(evt);
            }
        });
        jMenu4.add(eliminarDoc);

        menuInventario.add(jMenu4);

        jMenuBar1.add(menuInventario);

        jMenu2.setText("Alquiler");

        agregarAlquiler.setText("Agregar");
        agregarAlquiler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarAlquilerActionPerformed(evt);
            }
        });
        jMenu2.add(agregarAlquiler);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(labelNombre)
                    .addComponent(nombreCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                    .addComponent(labelApellido)
                    .addComponent(apellidoCliente)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(botonAgregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                        .addComponent(botonEliminar)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(datosNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(datosId, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(91, 91, 91))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(modoBus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(184, 184, 184))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(botonBuscar)
                                .addGap(211, 211, 211))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(comboCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombre)
                    .addComponent(modoBus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(datosNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(datosId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelApellido)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(apellidoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(botonBuscar)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(botonAgregar)
                            .addComponent(botonEliminar))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                        .addComponent(comboCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void eliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarClienteActionPerformed
        op2 = 1;
        ocultar(false);
        botonEliminar.setVisible(true);
        llenarTablaCliente();
       
    }//GEN-LAST:event_eliminarClienteActionPerformed

    private void agregarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarClienteActionPerformed
        ocultar(true);
        datosId.setVisible(false);
        datosNombre.setVisible(false);
        botonBuscar.setVisible(false);
        botonEliminar.setVisible(false);
        llenarTablaCliente();
       
    }//GEN-LAST:event_agregarClienteActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
         try{
             ocultar(true);
             if(validarCliente(nombreCliente.getText(),apellidoCliente.getText())){
               JOptionPane.showMessageDialog(null, "El cliente ya esta registrado");
               nombreCliente.setText(null);
               apellidoCliente.setText(null);
             }
             else {
                 noEditarTabla();
                 PreparedStatement ps = con.prepareStatement("insert into Clientes(nombre,apellido)values(?,?)");
                 ps.setString(1, nombreCliente.getText());
                 ps.setString(2, apellidoCliente.getText());
                 ps.executeUpdate();
                 JOptionPane.showMessageDialog(null, "Cliente agregado satisfactoriamente");
                 llenarTablaCliente();
                 nombreCliente.setText(null);
               apellidoCliente.setText(null);
             }
         }catch (SQLException ex){
           JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);  
        }
         
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void modificarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarClienteActionPerformed
           new Modificar(this,true,1).setVisible(true); 
    }//GEN-LAST:event_modificarClienteActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
      try {
          if (op2 == 1) {
              String eliminarC = "delete from Clientes where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
              PreparedStatement ps = con.prepareStatement(eliminarC);
              ps.execute();
              JOptionPane.showMessageDialog(null, "Cliente eliminado exitosamente");
              llenarTablaCliente();
          }
          else if(op2 == 2){
              String eliminarE = "delete from Empleados where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
              PreparedStatement ps = con.prepareStatement(eliminarE);
              ps.execute();
              JOptionPane.showMessageDialog(null, "Empleado eliminado exitosamente");
              llenarTablaEmpleado();
          }

      } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void modificarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarEmpleadoActionPerformed
        new Modificar(this,true,2).setVisible(true); 
    }//GEN-LAST:event_modificarEmpleadoActionPerformed

    private void eliminarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarEmpleadoActionPerformed
       op2=2;
       llenarTablaEmpleado();
       noEditarTabla();
       botonEliminar.setVisible(true);
       datosNombre.setVisible(false);
       datosId.setVisible(false);
       botonBuscar.setVisible(false);
    }//GEN-LAST:event_eliminarEmpleadoActionPerformed

    private void agregarPeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarPeliculaActionPerformed
      new Inventario(this,true,1).setVisible(true);         
    }//GEN-LAST:event_agregarPeliculaActionPerformed

    private void modificarPeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarPeliculaActionPerformed
        // TODO add your handling code here:
        new Modificar(this,true,3).setVisible(true); 
    }//GEN-LAST:event_modificarPeliculaActionPerformed

    private void agregarSerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarSerieActionPerformed
        // TODO add your handling code here:
        new Inventario(this,true,2).setVisible(true);   
    }//GEN-LAST:event_agregarSerieActionPerformed

    private void modificarSerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarSerieActionPerformed
        // TODO add your handling code here:
        new Modificar(this,true,4).setVisible(true); 
    }//GEN-LAST:event_modificarSerieActionPerformed

    private void eliminarPeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarPeliculaActionPerformed
        // TODO add your handling code here:
        new Inventario(this,true,5).setVisible(true);  
    }//GEN-LAST:event_eliminarPeliculaActionPerformed

    private void eliminarSerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarSerieActionPerformed
        // TODO add your handling code here:
        new Inventario(this,true,6).setVisible(true);  
    }//GEN-LAST:event_eliminarSerieActionPerformed

    private void agregarDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarDocActionPerformed
        // TODO add your handling code here:
        new Inventario(this,true,3).setVisible(true);  
    }//GEN-LAST:event_agregarDocActionPerformed

    private void modDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modDocActionPerformed
        // TODO add your handling code here:
        new Modificar(this,true,5).setVisible(true); 
    }//GEN-LAST:event_modDocActionPerformed

    private void eliminarDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarDocActionPerformed
        // TODO add your handling code here:
        new Inventario(this,true,7).setVisible(true); 
    }//GEN-LAST:event_eliminarDocActionPerformed

    private void datosNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_datosNombreActionPerformed
        // TODO add your handling code here:
        op3=1;
    }//GEN-LAST:event_datosNombreActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed

        if (op3 == 2) {
            if (datosNombre.getSelectedIndex() != 0) {
                datosId.setVisible(false);
                if (datosNombre.getSelectedIndex() == 0) {

                    JOptionPane.showMessageDialog(null, "Debe seleccionar una opción");
                } else {

                    String nombre = datosNombre.getSelectedItem().toString();;
                    if (datosNombre.getSelectedIndex() != 0) {

                        llenarTablaSelecCli(nombre);
                    }
                }

            }
        } else if (op3 == 1) {

            if (datosId.getSelectedIndex() == 0) {

                JOptionPane.showMessageDialog(null, "Debe seleccionar una opción");
            } else {

                String id = datosId.getSelectedItem().toString();;
                if (datosId.getSelectedIndex() != 0) {

                    llenarTablaSelecCliI(id);
                }
            }
        }
    }//GEN-LAST:event_botonBuscarActionPerformed

    private void consultarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarEmpleadoActionPerformed
        llenarTablaEmpleado();
        ocultar(false);
        datosNombre.setVisible(true);
        datosId.setVisible(true);
        botonBuscar.setVisible(true);
        String datos = "select  Id,nombre  from Empleados";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            datosId.removeAllItems();
            datosNombre.removeAllItems();
            datosNombre.addItem("Seleccione un Nombre");
            datosId.addItem("Seleccione un Id");
            while (resultado.next()) {
                datosId.addItem(resultado.getString("Id"));
                datosNombre.addItem(resultado.getString("nombre"));

            }
            

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }
    }//GEN-LAST:event_consultarEmpleadoActionPerformed

    private void modoBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modoBusActionPerformed
        int slec = modoBus.getSelectedIndex();  
        if (slec==1){
            llenarComboCli();
            modoBus.setSelectedIndex(0);
        }
        else if(slec ==2){
            llenarComboCliN();
            modoBus.setSelectedIndex(0);
        }
        
    }//GEN-LAST:event_modoBusActionPerformed

    private void datosIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_datosIdActionPerformed
        op3=2;
    }//GEN-LAST:event_datosIdActionPerformed

    private void agregarAlquilerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarAlquilerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agregarAlquilerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem agregarAlquiler;
    private javax.swing.JMenuItem agregarCliente;
    private javax.swing.JMenuItem agregarDoc;
    private javax.swing.JMenuItem agregarPelicula;
    private javax.swing.JMenuItem agregarSerie;
    private javax.swing.JTextField apellidoCliente;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JComboBox<String> comboCliente;
    private javax.swing.JMenuItem consultarEmpleado;
    private javax.swing.JComboBox<String> datosId;
    private javax.swing.JComboBox<String> datosNombre;
    private javax.swing.JMenuItem eliminarCliente;
    private javax.swing.JMenuItem eliminarDoc;
    private javax.swing.JMenuItem eliminarEmpleado;
    private javax.swing.JMenuItem eliminarPelicula;
    private javax.swing.JMenuItem eliminarSerie;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelApellido;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JMenu menuCliente;
    private javax.swing.JMenu menuEmpleado;
    private javax.swing.JMenu menuInventario;
    private javax.swing.JMenuItem modDoc;
    private javax.swing.JMenuItem modificarCliente;
    private javax.swing.JMenuItem modificarEmpleado;
    private javax.swing.JMenuItem modificarPelicula;
    private javax.swing.JMenuItem modificarSerie;
    private javax.swing.JComboBox<String> modoBus;
    private javax.swing.JTextField nombreCliente;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
