/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo;

/**
 *
 * @author Laboratorio
 */
public class Ejemplo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estudiante el = new Estudiante();
        el.nombre = "Carlitos";
        el.apellido = "Lopez";
        el.id = 1;
        System.out.println(el.toString());
        Profesor p1 = new Profesor();
        p1.id = 2;
        p1.apellido = "Perez";
        p1.nombre = "Pablo";
        System.out.println(p1.toString());
        Curso c1 = new Curso();
        c1.creditos = 4;
        c1.id = 3;
        c1.nombre = "Juan";
        System.out.println(c1.toString());
    }
    

}
