/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segundoejercicioexamenll;

import Clases.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Meibelyn
 */
public class menuPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form menuPrincipal
     *
     */
    Connection con = null;
    Conexion conect = new Conexion();
    private final String[] columnas = {"Id", "Nombre", "Director", "Productor", "Casa", "Protagonista", "Duracion", "Precio", "Genero", "Alquilado"};
    private final String[] columnasA = {"Id", "Nombre", "Director", "Productor", "Casa", "Protagonista", "Duracion", "Precio", "Genero", "Alquilado", ""};
    private final String[] columnasAlquiler = {"Id", "Total"};
    boolean limpiar;
    private int op2;
    private double total = 0, montoTotal = 0;

    public menuPrincipal() {
        initComponents();
        con = conect.getConnection();
    }

    public boolean validarPelicula(String nombre) {
        boolean existe = false;
        String info = "select nombre from Pelicula";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(info);
            while (resultado.next()) {
                if (resultado.getString("nombre").equals(nombrePelicula)) {
                    existe = true;
                    break;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + ex);
        }

        return existe;
    }

    public final void llenarTabla() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnas);
        Object[] columna = new Object[columnas.length];
        String datos = "select Id,nombre,director,productor,casa,protagonista,duracion,precio,genero,alquilado from Pelicula";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getString("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getString("productor");
                columna[4] = resultado.getString("casa");
                columna[5] = resultado.getString("protagonista");
                columna[6] = resultado.getInt("duracion");
                columna[7] = resultado.getInt("precio");
                columna[8] = resultado.getInt("genero");
                columna[9] = resultado.getBoolean("alquilado");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
        }
        tabla.setModel(tabla1);
    }

    private void noEditarTabla() {
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            Class<?> col_class = tabla.getColumnClass(i);
            tabla.setDefaultEditor(col_class, null);
        }
    }

    public void limpiarTex() {
        nombrePelicula.setText(" ");
        director.setText(" ");
        productor.setText(" ");
        casa.setText(" ");
        protagonista.setText(" ");
        duracion.setText(" ");
        precio.setText(" ");
        selecGenero.setSelectedIndex(0);

    }

    public void ocultar(boolean limpiar) {

        jLabel1.setVisible(limpiar);
        jLabel2.setVisible(limpiar);
        jLabel3.setVisible(limpiar);
        jLabel4.setVisible(limpiar);
        jLabel5.setVisible(limpiar);
        jLabel6.setVisible(limpiar);
        jLabel7.setVisible(limpiar);
        jLabel8.setVisible(limpiar);
        nombrePelicula.setVisible(limpiar);
        director.setVisible(limpiar);
        productor.setVisible(limpiar);
        casa.setVisible(limpiar);
        protagonista.setVisible(limpiar);
        duracion.setVisible(limpiar);
        precio.setVisible(limpiar);
        selecGenero.setVisible(limpiar);

    }

    public final void llenarTablaA() {
        DefaultTableModel tabla1 = new DefaultTableModel() {
            public Class<?> getColumnClass(int column) {
                //La columna la es la que quiero que sea checkbox por eso pongo boolean
                if (column == 10) {
                    return Boolean.class;
                } else if (column == 0 && column == 6 && column == 7 && column == 8) { //la columna 8 es el precio entonces es un double en mi caso
                    return Integer.class;
                } else {
                    return String.class; //todo lo que no sea la columna 6/7 u 8 es un string
                }
            }
        };
        tabla1.setColumnIdentifiers(columnasA);

        Object[] columna = new Object[columnasA.length];

        String datos = "select Id, nombre,genero,director,productor,casa,protagonista, duracion, precio,alquilado  from Pelicula";

        try {
            Statement st = con.createStatement();

            //Ejecuta la consulta y almacena los datos en resultado
            ResultSet resultado = st.executeQuery(datos);

            //Recorre la consulta realizada
            while (resultado.next()) {
                columna[0] = resultado.getInt("Id");
                columna[1] = resultado.getString("nombre");
                columna[2] = resultado.getString("director");
                columna[3] = resultado.getString("productor");
                columna[4] = resultado.getString("casa");
                columna[5] = resultado.getString("protagonista");
                columna[6] = resultado.getInt("duracion");
                columna[7] = resultado.getInt("precio");
                columna[8] = resultado.getInt("genero");
                if (resultado.getBoolean("alquilado")) {
                    columna[9] = "Alquilado";
                } else {
                    columna[9] = "Disponible";
                }

                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage());
        }
        tabla.setModel(tabla1);
    }
    public final void llenarTablaAlquiler() {
        DefaultTableModel tabla1 = new DefaultTableModel();
        tabla1.setColumnIdentifiers(columnasAlquiler);
        Object[] columna = new Object[columnasAlquiler.length];
        String datos = "select Id,monto from alquiler";
        try {
            Statement st = con.createStatement();
            ResultSet resultado = st.executeQuery(datos);
            while (resultado.next()) {
                columna[0] = resultado.getInt("Id");
                columna[1] = resultado.getInt("monto");
                tabla1.addRow(columna);
            }
            st.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos" + ex);
        }
        tabla.setModel(tabla1);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nombrePelicula = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        director = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        productor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        protagonista = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        casa = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        duracion = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        precio = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        selecGenero = new javax.swing.JComboBox<>();
        botonEliminar = new javax.swing.JButton();
        botonModificar = new javax.swing.JButton();
        botonAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuAgregar = new javax.swing.JMenu();
        Pelicula = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        nombrePelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombrePeliculaActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre Pelicula");

        jLabel2.setText("Director");

        director.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                directorActionPerformed(evt);
            }
        });

        jLabel3.setText("Productor");

        productor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productorActionPerformed(evt);
            }
        });

        jLabel4.setText("Casa");

        protagonista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                protagonistaActionPerformed(evt);
            }
        });

        jLabel5.setText("Protagonista");

        casa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                casaActionPerformed(evt);
            }
        });

        jLabel6.setText("Duracion (min)");

        duracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                duracionActionPerformed(evt);
            }
        });

        jLabel7.setText("Precio");

        precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioActionPerformed(evt);
            }
        });

        jLabel8.setText("Genero");

        selecGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un genero", "Terror", "Accion", "Drama", "Comedia" }));

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });

        botonAgregar.setText("Agregar");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        menuAgregar.setText("Agregar");

        Pelicula.setText("Pelicula");
        Pelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PeliculaActionPerformed(evt);
            }
        });
        menuAgregar.add(Pelicula);

        jMenuItem1.setText("Alquiler");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        menuAgregar.add(jMenuItem1);

        jMenuBar1.add(menuAgregar);

        jMenu2.setText("Salir");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(director, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(nombrePelicula, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(productor, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonModificar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonEliminar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonAgregar, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(duracion, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5)
                            .addComponent(casa, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(protagonista, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(selecGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nombrePelicula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(director, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonAgregar, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(botonModificar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonEliminar)
                            .addComponent(productor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(casa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)))
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(protagonista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(duracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(selecGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombrePeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombrePeliculaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombrePeliculaActionPerformed

    private void directorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_directorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_directorActionPerformed

    private void productorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_productorActionPerformed

    private void protagonistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_protagonistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_protagonistaActionPerformed

    private void casaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_casaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_casaActionPerformed

    private void duracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_duracionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_duracionActionPerformed

    private void precioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precioActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        try {
            switch (op2) {
                case 1:
                    try {
                        if (validarPelicula(nombrePelicula.getText())) {
                            JOptionPane.showMessageDialog(null, "La pelicula ya esta registrada");
                        } else {
                            PreparedStatement ps = con.prepareStatement("insert into Pelicula(nombre, director,productor,casa,protagonista,duracion,precio,genero)values(?,?,?,?,?,?,?,?)");
                            ps.setString(1, nombrePelicula.getText());
                            ps.setString(2, director.getText());
                            ps.setString(3, productor.getText());
                            ps.setString(4, casa.getText());
                            ps.setString(5, protagonista.getText());
                            ps.setInt(6, Integer.parseInt(duracion.getText()));

                            ps.setInt(8, selecGenero.getSelectedIndex());
                            if (selecGenero.getSelectedIndex() == 1) {
                                JOptionPane.showMessageDialog(null, "Selecciono el genero Terror,se le realizara un cargo del 10%");
                                total = (Integer.parseInt(precio.getText()) + (Integer.parseInt(precio.getText()) * 0.10));
                                ps.setDouble(7, total);

                            } else if (selecGenero.getSelectedIndex() == 2) {
                                JOptionPane.showMessageDialog(null, "Selecciono el genero Accion,se le realizara un cargo del 15%");
                                total = (Integer.parseInt(precio.getText()) + (Integer.parseInt(precio.getText()) * 0.15));
                                ps.setDouble(7, total);
                            } else if (selecGenero.getSelectedIndex() == 3) {
                                JOptionPane.showMessageDialog(null, "Selecciono el genero Drama,se le realizara un descuento del 20%");
                                total = (Integer.parseInt(precio.getText()) - (Integer.parseInt(precio.getText()) * 0.20));
                                ps.setDouble(7, total);
                            } else {
                                JOptionPane.showMessageDialog(null, "Selecciono el genero Comedia,se le realizara un cargo del 5%");
                                total = (Integer.parseInt(precio.getText()) + (Integer.parseInt(precio.getText()) * 0.5));
                                ps.setDouble(7, total);
                            }

                            ps.executeUpdate();
                            JOptionPane.showMessageDialog(null, "¡Guardado!");
                            ps.close();
                            llenarTabla();
                            limpiarTex();
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Se ha producido un error al agregar los datos" + e);
                    }
                    break;
                case 2:
                    try {
                        int peliAlquilar = 0;
                        int precio;
                        for (int i = 0; i < tabla.getRowCount(); i++) {
                            if (tabla.getValueAt(i, 10) instanceof Boolean) {
                                precio = Integer.parseInt(tabla.getValueAt(i, 7).toString());
                                montoTotal = montoTotal + precio;
                            }
                        }
                        PreparedStatement ps = con.prepareStatement("insert into alquiler(monto)values(?)");
                        ps.setDouble(1, montoTotal);
                        JOptionPane.showMessageDialog(null, montoTotal);
                        ps.executeUpdate();
                        for (int i = 0; i < tabla.getRowCount(); i++) {
                            if (tabla.getValueAt(i, 10) instanceof Boolean) {
                                peliAlquilar = Integer.parseInt(tabla.getValueAt(i, 0).toString());
                                JOptionPane.showMessageDialog(null, peliAlquilar);
                                ps = con.prepareStatement("update pelicula set alquilado='" + true + "',IdAlquiler=(select MAX(Id) from alquiler) where Id='" + peliAlquilar + "'");
                                ps.executeUpdate();

                            }
                        }
                        ps.close();
                        montoTotal = 0;

                        break;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Se ha producido un error al agregar los datos" + e);
                    }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Se ha producido un error al agregar los datos" + e);
        }

    }//GEN-LAST:event_botonAgregarActionPerformed

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed

        try {
            String datos = "update pelicula set nombre=?,director=?,productor=?,casa=?,protagonista=?,duracion=?,precio=?,genero=?    where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'";
            PreparedStatement ps = con.prepareStatement(datos);
            ps.setString(1, nombrePelicula.getText());
            ps.setString(2, director.getText());
            ps.setString(3, productor.getText());
            ps.setString(4, casa.getText());
            ps.setString(5, protagonista.getText());
            ps.setInt(6, Integer.parseInt(duracion.getText()));
            ps.setInt(7, Integer.parseInt(precio.getText()));
            ps.setInt(8, selecGenero.getSelectedIndex());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Modificado exitosamente");

            ps.close();

            llenarTabla();
            limpiarTex();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Se ha producido un error al guardar los datos" + e);
        }
    }//GEN-LAST:event_botonModificarActionPerformed

    private void PeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PeliculaActionPerformed
        // TODO add your handling code here:
        op2=1;
        llenarTabla();
        noEditarTabla();
        ocultar(limpiar=true);
    }//GEN-LAST:event_PeliculaActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
       switch(op2){
            case 1:
                try {
                    String eliminar = "delete from Pelicula where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
                    PreparedStatement ps = con.prepareStatement(eliminar);
                    ps.execute();
                    JOptionPane.showMessageDialog(null, "Eliminado exitosamente");
                    llenarTabla();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Se ha producido un error al eliminar los datos" + e);
                }
            case 2:
                try {
                    llenarTablaAlquiler();
                    noEditarTabla();
                    String eliminar = "delete from alquiler where Id = '" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "' ";
                    PreparedStatement ps = con.prepareStatement(eliminar);
                    ps.execute();
                     ps = con.prepareStatement("update alquiler set alquilado='" + false + "',IdAlquiler = '" + 0 + "' where Id='" + Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) + "'");
                    JOptionPane.showMessageDialog(null, "Eliminado exitosamente");
                    llenarTablaAlquiler();
                    ps.executeUpdate();
                    break;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Se ha producido un error al eliminar los datos" + e);
                }

        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked

        if (tabla.getColumnCount() == 10) {
            if (tabla.getColumnCount() == 1) {
                nombrePelicula.setText(tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                director.setText(tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                productor.setText(tabla.getValueAt(tabla.getSelectedRow(), 3).toString());
                casa.setText(tabla.getValueAt(tabla.getSelectedRow(), 4).toString());
                protagonista.setText(tabla.getValueAt(tabla.getSelectedRow(), 5).toString());
                duracion.setText(tabla.getValueAt(tabla.getSelectedRow(), 6).toString());
                precio.setText(tabla.getValueAt(tabla.getSelectedRow(), 7).toString());
                selecGenero.setSelectedIndex(Integer.parseInt(tabla.getValueAt(tabla.getSelectedRow(), 8).toString()));
            }
        } 
        else if (tabla.getColumnCount() == 2) {
            tabla.setCellSelectionEnabled(false);
            tabla.setRowSelectionAllowed(true);
        } 
        else if (tabla.getColumnCount() == 11) {
            tabla.setCellSelectionEnabled(true);
            if (tabla.isCellSelected(tabla.getSelectedRow(), 10)) {
                if (tabla.getValueAt(tabla.getSelectedRow(), 10).equals(true)) {
                    tabla.setColumnSelectionInterval(0, 10);
                    
                } 
            }

        }
    }//GEN-LAST:event_tablaMouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        botonModificar.setVisible(false);
        llenarTablaA();
        op2=2;
        ocultar(limpiar=false);
 
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Pelicula;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonModificar;
    private javax.swing.JTextField casa;
    private javax.swing.JTextField director;
    private javax.swing.JTextField duracion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuAgregar;
    private javax.swing.JTextField nombrePelicula;
    private javax.swing.JTextField precio;
    private javax.swing.JTextField productor;
    private javax.swing.JTextField protagonista;
    private javax.swing.JComboBox<String> selecGenero;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
