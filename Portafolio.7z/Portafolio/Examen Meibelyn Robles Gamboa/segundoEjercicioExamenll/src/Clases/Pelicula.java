/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Meibelyn
 */
public class Pelicula {
    private int Id;
     private String nombre;
     private String productor;
     private String casa;
     private String protagonista;
     private String duracion;
     private String precio;
     private String genero;
     
     public Pelicula(){
         
     }

    public Pelicula(int Id, String nombre, String productor, String casa, String protagonista, String duracion, String precio, String genero) {
        this.Id = Id;
        this.nombre = nombre;
        this.productor = productor;
        this.casa = casa;
        this.protagonista = protagonista;
        this.duracion = duracion;
        this.precio = precio;
        this.genero = genero;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getProductor() {
        return productor;
    }

    public void setProductor(String productor) {
        this.productor = productor;
    }

    public String getCasa() {
        return casa;
    }

    public void setCasa(String casa) {
        this.casa = casa;
    }

    public String getProtagonista() {
        return protagonista;
    }

    public void setProtagonista(String protagonista) {
        this.protagonista = protagonista;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
     
}
