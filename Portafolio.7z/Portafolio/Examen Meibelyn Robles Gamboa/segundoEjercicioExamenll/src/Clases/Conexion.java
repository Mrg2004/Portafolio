/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion extends Pelicula {
    Connection con=null;
    
    public Conexion(){
        try{
            con=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Meibelyn\\Documents\\UAM\\Progra ll\\Examen Meibelyn Robles Gamboa\\segundoEjercicioExamenll\\Peliculas.accdb");
            Statement st = con.createStatement();
             JOptionPane.showMessageDialog(null, "Conexion exitosa" );
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Conexion erronea" + e);
        }
        
    }
    
    public Connection getConnection(){
        return con;
    }
}
