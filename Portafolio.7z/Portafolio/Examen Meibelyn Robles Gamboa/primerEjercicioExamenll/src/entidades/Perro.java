/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author Meibelyn
 */
public class Perro extends Animal{
    public Perro() {
    }

    @Override
    public void setHablar(String hablar) {
        super.setHablar(hablar); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getHablar() {
        return super.getHablar(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }
    

    
}
