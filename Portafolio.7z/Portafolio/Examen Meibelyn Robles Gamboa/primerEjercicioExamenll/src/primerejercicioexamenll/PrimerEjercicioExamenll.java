/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerejercicioexamenll;

import java.util.ArrayList;
import entidades.Animal;
import entidades.Gato;
import entidades.Perro;
import entidades.Pato;
import entidades.Vaca;
import java.util.Random;

/**
 *
 * @author Meibelyn
 */
public class PrimerEjercicioExamenll {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random aleatorio = new Random();
        int contPerro =1;
        int contVaca =1;
        int contPato =1;
        int contGato =1;
        int contGen =0, contI =1;
        ArrayList <Animal> animales = new ArrayList();
        System.out.println("Iteracion " +contI);
        do {
            contGen ++;
            if(contGen ==9){
                contGen=0;
                contI ++;
                System.out.println("Iteracion " + contI);
                
            }
            int posicion = aleatorio.nextInt(3);
            if(posicion ==0){
                Animal perro = new Perro();
                perro.setNombre("Perro");
                perro.setHablar("GUAU");
                perro.setContador(contPerro++);
                System.out.println("Creado un perro");
                System.out.println(perro.toString());
                
                perro.toString();  
            }
            else if (posicion ==1){
                Animal gato = new Gato();
                gato.setNombre("Gato");
                gato.setHablar("MIAU");
                gato.setContador(contGato++);
                System.out.println("Creado un gato");
                System.out.println(gato.toString());;  
            }
            else if (posicion ==2){
                Animal pato = new Pato();
                pato.setNombre("Pato");
                pato.setHablar("CUAC");
                pato.setContador(contPato++);
                System.out.println("Creado un pato");
            System.out.println(pato.toString());
            }
            else {
                Animal vaca = new Vaca();
                vaca.setNombre("Vaca");
                vaca.setHablar("MUUU");
                vaca.setContador(contVaca++);
                System.out.println("Creada una vaca");
                System.out.println(vaca.toString());  
            }

        } while (true);

    }

}
