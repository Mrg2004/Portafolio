/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerparcialtercerapartesegundoejercicio;

import entidades.Persona;
import util.Utilidades;
import entidades.Estudiante;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Meibelyn Robles
 */
public class PrimerParcialTerceraParteSegundoEjercicio extends Utilidades  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Se crea una lista para guardar los nombres que se agregan a la lista
        List<Persona> personas = new ArrayList<Persona>();
        //se crea una instancia para lkas clase estudiante en donde se agrega los atributos
        Persona persona = new Estudiante();
        //Se agregan atributos
        persona.setNombre("Carlitos");
        persona.setsexo("Masculino");
        personas.add(persona);
        //Se imprime la lista
        try {
            imprimirPersonas(personas);
        } catch (Exception e) {
            System.out.println(e);
        }
        //Se crea uan intancia para agregar cualidades al objeto
        Utilidades utile = new Utilidades() {
        };
        //se le indica a la clase el numero que se le va a gregar para realizar la operacion
        int resultado = utile.getSuma(1, 1);
        int resultadoResta = utile.getResta(3, 2);
        System.out.println("El resultado de la suma es: " + resultado);
        System.out.println("El resultado de la resta es: " + resultadoResta);
    }

    //metodo para imprimir la lista
    public static void imprimirPersonas(
            List<Persona> personas)
            throws Exception {
        for (Persona persona : personas) {
            System.out.println(
                    persona.getNombre() + "\n" + persona.getsexo());
        }
    }
}
