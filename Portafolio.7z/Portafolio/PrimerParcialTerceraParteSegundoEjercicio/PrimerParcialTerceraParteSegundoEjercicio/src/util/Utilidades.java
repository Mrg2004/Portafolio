package util;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Meibelyn Robles
 */
public abstract class Utilidades {

    protected int suma;
    protected int resta;

    public Utilidades() {
    }

    public Utilidades(int num1, int num2) {
        this.suma = suma;
        this.resta = resta;
    }

    public int getSuma(int num1, int num2) {
        return (num1 + num2);
    }

    public void setSuma(int suma) {
        this.suma = suma;
    }

    public int getResta(int num1, int num2) {
        return (num1 - num2);
    }

    public void setResta(int resta) {
        this.resta = resta;
    }

}
