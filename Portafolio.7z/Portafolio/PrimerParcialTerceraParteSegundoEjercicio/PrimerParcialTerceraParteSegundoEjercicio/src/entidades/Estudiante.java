/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author Meibelyn
 */
//Se crea la clase estudiante para que extienda de persona y asi obtener los atributos de esta
public class Estudiante extends Persona  {
    //Se crean los contructures para inicializar las variables

    public Estudiante() {
    }

    public Estudiante(String nombre) {
        this.nombre = nombre;
    }

    public Estudiante(
            String nombre,
            String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public Estudiante(
            String nombre,
            String apellido,
            int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public Estudiante(
            String nombre,
            String apellido,
            int edad,
            String sexo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.sexo = sexo;
    }

    //Se crean los setters y los getters
    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getNombre() {
        return this.nombre;
    }

    @Override
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String getApellido() {
        return this.apellido;
    }

    @Override
    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public int getEdad() {
        return this.edad;
    }

    @Override
    public void setsexo(String sexo) {
        this.sexo = sexo;
    }

    @Override
    public String getsexo() {
        return this.sexo;

    }

}
