/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author Meibelyn Robles
 */
public abstract class Persona {

    protected String nombre;
    protected String apellido;
    protected int edad;
    //Se agrega la variable sexo porque se necesitaba segun el set de la clase primerParcial...
    protected String sexo;
    //Se crean los setters y los getters

    public abstract void setNombre(String nombre);

    public abstract String getNombre();

    public abstract void setApellido(String apellido);

    public abstract String getApellido();

    public abstract void setEdad(int edad);

    public abstract int getEdad();

    public abstract void setsexo(String sexo);

    public abstract String getsexo();

}
